package test;

import com.superhero.dao.Superheros;
import com.superhero.database.DatabaseDao;
import com.superhero.dao.SuperherosDao;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = Superheros.class)
public class testSuperhero {

    @BeforeAll
    public static void setUpClass() {
        DatabaseDao db = new DatabaseDao();
        db.getAllSupers();
    }

    @Test
    public void testAdd() throws SQLException {
        SuperherosDao superhero = new SuperherosDao();
        superhero.setIDSuperhero(999);
        superhero.setName("Name");
        superhero.setDescription("Description");
        superhero.setIDOrg(666);
        int newsh = SuperherosDao.Superheros.size() - 1;
        assertEquals(superhero, SuperherosDao.Superheros.get(newsh));
        SuperherosDao.Superheros.remove(superhero);
    }

    @Test
    public void testContains() throws SQLException {
        SuperherosDao superherotwo = new SuperherosDao();
        superherotwo.setIDSuperhero(999);
        superherotwo.setName("Name");
        superherotwo.setDescription("Description");
        superherotwo.setIDOrg(666);
        assertTrue(SuperherosDao.Superheros.contains(superherotwo));
        SuperherosDao.Superheros.remove(superherotwo);
    }
}
