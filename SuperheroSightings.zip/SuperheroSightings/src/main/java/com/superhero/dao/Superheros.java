package com.superhero.dao;

public interface Superheros {
    public String getName();
    public void setName(String name);
    public void setDescription(String description);
    public void setIDSuperpower(int superpowers);
    public void setIDOrg(int idorg);
    public void setIDSuperhero(int idhero);
    public int getIDSuperhero();
}
