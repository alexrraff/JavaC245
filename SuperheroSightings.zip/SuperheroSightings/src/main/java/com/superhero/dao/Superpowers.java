package com.superhero.dao;

public interface Superpowers {
    public void setIDSuperpower(int idsp);
    public void setName(String name);
    public void setDescription(String description);
    public int getIDSuperpower();
}
