package com.superhero.dao;

public interface Sightings {
    public void setIDSighting(int idsight);
    public void setIDSuperhero(int ids);
    public void setIDLocation(int idloc);
    public void setDateTime(int dt);
    public int getIDSuper();
    public int getIDLoc();
    public int getIDSighting();
    public int getDatetime();
}
