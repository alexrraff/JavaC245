package com.superhero.dao;

public interface Organizations {
    public void setIDOrganization(int idorg);
    public void setName(String name);
    public void setAddress(String address);
    public void setContactinfo(String ci);
    public int getIDOrganization();
}
