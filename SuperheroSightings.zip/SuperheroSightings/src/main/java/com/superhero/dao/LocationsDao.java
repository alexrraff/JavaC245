package com.superhero.dao;

import com.superhero.database.DatabaseDao;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.ArrayList;
@Repository
public class LocationsDao implements Locations {

    public int idlocation;
    public String name, description, addressinfo, latlon;

    public static ArrayList<LocationsDao> Locations = new ArrayList<LocationsDao>();

    public LocationsDao() {
        this.setIDLocation(Locations.size());
        Locations.add(this);
    }
    @Override
    public void setIDLocation(int idloc) {this.idlocation = idloc;}
    @Override
    public void setName(String name) {this.name = name;}
    @Override
    public void setDescription(String description) {this.description = description;}
    @Override
    public void setAddressInfo(String addinfo) {this.addressinfo = addinfo;}
    @Override
    public void setLatlon(String latlon) {this.latlon = latlon;}
    @Override
    public int getIDLocation() {return this.idlocation;}
    //Getters and Setters and Constructor

    public static void addDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.createLocation(LocationsDao.Locations.get(ids));
    };
    //Create database object and call database method to create it in MySQL DB
}
