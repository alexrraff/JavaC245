package com.superhero.dao;

import com.superhero.database.DatabaseDao;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.ArrayList;
@Repository
public class OrganizationsDao implements Organizations {

    public int idorganization;
    public String name, address, contactinfo;

    public static ArrayList<OrganizationsDao> Organizations = new ArrayList<OrganizationsDao>();

    public OrganizationsDao() {
        this.setIDOrganization(Organizations.size());
        Organizations.add(this);
    }

    @Override
    public void setIDOrganization(int idorg) {this.idorganization = idorg;}
    @Override
    public void setName(String name) {this.name = name;}
    @Override
    public void setAddress(String address) {this.address = address;}
    @Override
    public void setContactinfo(String ci) {this.contactinfo = ci;}
    @Override
    public int getIDOrganization() {return this.idorganization;}
    //Getters and Setters and Constructor

    public static void addDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.createOrganization(OrganizationsDao.Organizations.get(ids));
    };
    //Create database object and call database method to create it in MySQL DB

}
