package com.superhero.dao;

import com.superhero.database.DatabaseDao;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.ArrayList;
@Repository
public class SuperherosDao implements Superheros {
    public String name, description;
    public int idsuperhero, idorganization, idsuperpower;

    public static ArrayList<SuperherosDao> Superheros = new ArrayList<SuperherosDao>();

    public SuperherosDao() throws SQLException {
        int bignum;
        int bigid;
        if (Superheros.size() != 0) {
            bignum = Superheros.size() - 1;
            bigid = Superheros.get(bignum).idsuperhero;
            bigid += 1;
        } else {
            bigid = 1;
        }
        Superheros.add(this);
        this.setIDSuperhero(bigid);
    }
    //Get the idSuperhero of the object with the highest index
    //Add 1 to that id to get next biggest id

    @Override
    public String getName() {return this.name;}
    @Override
    public int getIDSuperhero() {return this.idsuperhero;};
    @Override
    public void setName(String name) {this.name = name;}
    @Override
    public void setDescription(String description) {this.description = description;}
    @Override
    public void setIDSuperpower(int superpowers) {this.idsuperpower = superpowers;}
    @Override
    public void setIDOrg(int idorg) {this.idorganization = idorg;}
    @Override
    public void setIDSuperhero(int idhero) {this.idsuperhero = idhero;}
    //Getters and Setters and Constructor

    public static void addDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.createSuperhero(SuperherosDao.Superheros.get(SuperherosDao.Superheros.size() - 1));
    };
    //Create database object and call database method to create it in MySQL DB

    public static void deleteSuper(int ids) throws SQLException {
        ids -= 1;
        DatabaseDao db = new DatabaseDao();
        int idsh = Superheros.get(ids).getIDSuperhero();
        db.deleteSuperhero(idsh);
        Superheros.remove(Superheros.get(ids));
    };
    //Method to remove from ArrayList and call database method to remove from MySQL db
    //It gets the superhero number but subtract one since index starts at 1

    public static void editSuper(int num, int choice, String fieldnew) throws SQLException {
        num -= 1;
        switch (choice) {
            case 1:
                Superheros.get(num).setName(fieldnew);
                break;
            case 2:
                Superheros.get(num).setDescription(fieldnew);
                break;
            case 3:
                Superheros.get(num).setIDSuperpower(Integer.parseInt(fieldnew));
                break;
            case 4:
                Superheros.get(num).setIDOrg(Integer.parseInt(fieldnew));
                break;
        }
        DatabaseDao db = new DatabaseDao();
        int idsh = Superheros.get(num).getIDSuperhero();
        db.editSuperhero(idsh, choice, fieldnew);
    };
    //4 Cases depending on which field to edit and parse if needs Integer
    //Call database method to edit entry in MySQL

}
