package com.superhero.dao;

import com.superhero.database.DatabaseDao;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.ArrayList;
@Repository
public class SuperpowersDao implements Superpowers {

    public int idsuperpower;
    public String description, name;

    public static ArrayList<SuperpowersDao> Superpowers = new ArrayList<SuperpowersDao>();

    public SuperpowersDao() {
        this.setIDSuperpower(Superpowers.size());
        Superpowers.add(this);
    }
    @Override
    public void setIDSuperpower(int idsp) {this.idsuperpower = idsp;}
    @Override
    public void setName(String name) {this.name = name;}
    @Override
    public void setDescription(String description) {this.description = description;}
    @Override
    public int getIDSuperpower() {return this.idsuperpower;}
    //Getters and Setters and Constructor

    public static void addDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.createSuperpower(SuperpowersDao.Superpowers.get(ids));
    };
    //Create database object and call database method to create it in MySQL DB

}
