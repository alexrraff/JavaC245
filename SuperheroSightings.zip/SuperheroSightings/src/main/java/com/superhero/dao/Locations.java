package com.superhero.dao;

import com.superhero.database.DatabaseDao;

import java.sql.SQLException;

public interface Locations {
    public void setIDLocation(int idloc);

    public void setName(String name);
    public void setDescription(String description);
    public void setAddressInfo(String addinfo);
    public void setLatlon(String latlon);
    public int getIDLocation();

}
