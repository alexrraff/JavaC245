package com.superhero.dao;

import com.superhero.database.DatabaseDao;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.ArrayList;
@Repository
public class SightingsDao implements Sightings{

    public int idsighting, idsuperhero, idlocation, datetime;
    public static ArrayList<SightingsDao> Sightings = new ArrayList<SightingsDao>();

    public SightingsDao() {
        this.setIDSighting(Sightings.size());
        Sightings.add(this);
    }
    @Override
    public void setIDSighting(int idsight) {this.idsighting = idsight;}
    @Override
    public void setIDSuperhero(int ids) {this.idsuperhero = ids;}
    @Override
    public void setIDLocation(int idloc) {this.idlocation = idloc;}
    @Override
    public void setDateTime(int dt) {this.datetime = dt;}
    @Override
    public int getIDSuper() {return this.idsuperhero;}
    @Override
    public int getIDLoc() {return this.idlocation;}
    @Override
    public int getIDSighting() {return this.idsighting;}
    @Override

    public int getDatetime() {return this.datetime;}
    //Getters and Setters and Constructor

    public static void addDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.createSighting(SightingsDao.Sightings.get(ids));
    };
    //Create database object and call database method to create it in MySQL DB
}
