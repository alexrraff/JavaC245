package com.superhero.controller;

import com.superhero.dao.*;
import com.superhero.database.DatabaseDao;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.SQLException;
import java.util.ArrayList;

@Controller
public class MainController {
    String name,superheroName,superheroDescription;
    String locationName, locationDescription, locationAddinfo, locationLatlon;
    String superpowerName, superpowerDescription, superpowerId;
    String organizationId, organizationName, organizationAddress, organizationContactinfo;
    int locationIdLocation, superheroIdSuperpower, superheroIdOrganization;
    int sightingIdSighting, sightingIdLocation, sightingIdSuperhero,sightingDate;
    //Create public variables that can be seen by all methods

    @RequestMapping("superhero")
    public String displaySuperheros(Model supermodel) {
        supermodel.addAttribute("superheros", SuperherosDao.Superheros);
        return "superhero";
    }
    //Add the superheros ArrayList to the model and return to page

    @PostMapping("superheroCreate")
    public String addSuperhero(HttpServletRequest request) throws SQLException {
        superheroName = request.getParameter("formName");
        superheroDescription = request.getParameter("formDescription");
        superheroIdSuperpower = Integer.parseInt(request.getParameter("formIdSuperpower"));
        superheroIdOrganization = Integer.parseInt(request.getParameter("formIdOrganization"));
        SuperherosDao superheronew = new SuperherosDao();
        superheronew.setName(superheroName);
        superheronew.setDescription(superheroDescription);
        superheronew.setIDSuperpower(superheroIdSuperpower);
        superheronew.setIDOrg(superheroIdOrganization);
        int ids = superheronew.getIDSuperhero();
        superheronew.addDb(ids);
        return "redirect:/superhero";
    }
    //Create superhero object getting the inputs from form in the html page
    //Add the object to the DB as well

    @PostMapping("sightingviewCreate")
    public String addSightingview(HttpServletRequest request) throws SQLException {
        int date = Integer.parseInt(request.getParameter("formDateYear") + request.getParameter("formDateMonth") + request.getParameter("formDateDay"));
        return "redirect:/sightingdateview/" + date;
    }
    @PostMapping("sightingviewsuperlocCreate")
    public String addSightingsuperlocview(HttpServletRequest request) throws SQLException {
        int locID = Integer.parseInt(request.getParameter("formLID"));
        return "redirect:/sightingsuperloc/" + locID;
    }
    //Use inputs from html pages and pass to RequestMapping

    @RequestMapping("sightingsuperloc/{lid}")
    public String displaySightingsuperloc(Model sightingsuperlocmodel, @PathVariable int lid) {
        ArrayList<SightingsDao> SightingSuperLocs = new ArrayList<SightingsDao>();
        for (int i = 0; i < SightingsDao.Sightings.size(); i++) {
            if (SightingsDao.Sightings.get(i).getIDLoc() == lid) {
                SightingSuperLocs.add(SightingsDao.Sightings.get(i));
            }
        }
        sightingsuperlocmodel.addAttribute("sightingsuperlocs", SightingSuperLocs);
        return "sightingsuperloc";
    }
    @RequestMapping("sightingdateview/{sightingDate}")
    public String displaySightingdate(Model sightingviewdatemodel, @PathVariable int sightingDate) {
        ArrayList<SightingsDao> SightingDates = new ArrayList<SightingsDao>();
        for (int i = 0; i < SightingsDao.Sightings.size(); i++) {
            if (SightingsDao.Sightings.get(i).getDatetime() == sightingDate) {
                SightingDates.add(SightingsDao.Sightings.get(i));
            }
        }
        sightingviewdatemodel.addAttribute("sightingdates", SightingDates);
        return "sightingdateview";
    }
    //Use the pathvariables to cycle through the ArrayList
    //If an attribute of an arraylist object equals the path variable
    //Add it to a new arraylist that will be passed back to sightingdateview/sightingsuperloc

    @RequestMapping("sighting")
    public String displaySightings(Model sightingmodel) {
        ArrayList<SightingsDao> ordersightings = new ArrayList<SightingsDao>();

        for (int i = SightingsDao.Sightings.size()-1; i >= 0; i--) {
            ordersightings.add(SightingsDao.Sightings.get(i));
        }
        sightingmodel.addAttribute("sightings", SightingsDao.Sightings);
        return "sighting";
    }
    @PostMapping("sightingCreate")
    public String addSighting(HttpServletRequest request) throws SQLException {
        sightingIdLocation = Integer.parseInt(request.getParameter("formLocation"));
        sightingIdSuperhero = Integer.parseInt(request.getParameter("formSuperhero"));
        sightingDate = Integer.parseInt(request.getParameter("formDateYear") + request.getParameter("formDateMonth")
        + request.getParameter("formDateDay"));
        SightingsDao sightingnew = new SightingsDao();
        sightingnew.setIDLocation(sightingIdLocation);
        sightingnew.setIDSuperhero(sightingIdSuperhero);
        sightingnew.setDateTime(sightingDate);
        int ids = sightingnew.getIDSighting();
        sightingnew.addDb(ids);
        return "redirect:/sighting";
    }
    //Create using the same method as Sighting

    @RequestMapping("location")
    public String displayLocations(Model locationmodel) {
        ArrayList<LocationsDao> orderlocations = new ArrayList<LocationsDao>();

        for (int i = OrganizationsDao.Organizations.size()-1; i >= 0; i--) {
            orderlocations.add(LocationsDao.Locations.get(i));
        }
        locationmodel.addAttribute("locations", orderlocations);
        return "location";
    }
    @PostMapping("locationCreate")
    public String addLocation(HttpServletRequest request) throws SQLException {
        locationName = request.getParameter("formName");
        locationDescription = request.getParameter("formDescription");
        locationAddinfo = request.getParameter("formAddinfo");
        locationLatlon = request.getParameter("formLatlon");
        LocationsDao locationnew = new LocationsDao();
        locationnew.setAddressInfo(locationAddinfo);
        locationnew.setName(locationName);
        locationnew.setDescription(locationDescription);
        locationnew.setLatlon(locationLatlon);
        int ids = locationnew.getIDLocation();
        locationnew.addDb(ids);
        return "redirect:/location";
    }
    //Create using the same method as Sighting

    @RequestMapping("organization")
    public String displayOrganizations(Model organizationmodel) {
        ArrayList<OrganizationsDao> orderpowers = new ArrayList<OrganizationsDao>();

        for (int i = OrganizationsDao.Organizations.size()-1; i >= 0; i--) {
            orderpowers.add(OrganizationsDao.Organizations.get(i));
        }
        organizationmodel.addAttribute("organizations", orderpowers);
        return "organization";
    }
    @PostMapping("organizationCreate")
    public String addOrganization(HttpServletRequest request) throws SQLException {

        organizationName = request.getParameter("formName");
        organizationAddress = request.getParameter("formAddress");
        organizationContactinfo = request.getParameter("formContactinfo");
        OrganizationsDao organizationnew = new OrganizationsDao();
        organizationnew.setName(organizationName);
        organizationnew.setAddress(organizationAddress);
        organizationnew.setContactinfo(organizationContactinfo);
        int ids = organizationnew.getIDOrganization();
        organizationnew.addDb(ids);
        return "redirect:/organization";
    }
    //Create using the same method as Sighting

    @RequestMapping("superpower")
    public String displaySuperpower(Model superpowermodel) {
        ArrayList<SuperpowersDao> orderpowers = new ArrayList<SuperpowersDao>();

        for (int i = SuperpowersDao.Superpowers.size()-1; i >= 0; i--) {
            orderpowers.add(SuperpowersDao.Superpowers.get(i));
        }
        superpowermodel.addAttribute("superpowers", orderpowers);
        return "superpower";
    }
    @PostMapping("superpowerCreate")
    public String addSuperpower(HttpServletRequest request) throws SQLException {

        superpowerName = request.getParameter("formName");
        superpowerDescription = request.getParameter("formDescription");
        SuperpowersDao superpowernew = new SuperpowersDao();
        superpowernew.setName(superpowerName);
        superpowernew.setDescription(superpowerDescription);
        int ids = superpowernew.getIDSuperpower();
        superpowernew.addDb(ids);
        return "redirect:/superpower";
    }
    //Create using the same method as Sighting

    @RequestMapping("superheroview/{heroId}")
    public String displaySuperheroview(Model superheroviewmodel, @PathVariable int heroId) {
        heroId -= 1;
        superheroviewmodel.addAttribute("superhero", SuperherosDao.Superheros.get(heroId));
        int superheroviewpower = SuperherosDao.Superheros.get(heroId).idsuperpower;
        superheroviewmodel.addAttribute("superpower", SuperpowersDao.Superpowers.get(superheroviewpower));
        int superherovieworganization = SuperherosDao.Superheros.get(heroId).idorganization;
        superheroviewmodel.addAttribute("organization", OrganizationsDao.Organizations.get(superherovieworganization));
        return "superheroview";
    }
    //Use the superheroid to get a specific superheroobject
    //Then get the superowerid and organizationid from object attributes
    //Assign a superhero,organization,and superpower object to the model by using ids

    @PostMapping("superheroviewCreate")
    public String addSuperheroview(HttpServletRequest request) throws SQLException {
        int superheroview = Integer.parseInt(request.getParameter("formId"));
        return "redirect:/superheroview/" + superheroview;
    }
    //Create using the same method as Sighting

    @PostMapping("superheroDelete")
    public String deleteSuperhero(HttpServletRequest request) throws SQLException {
        int superherodelete = Integer.parseInt(request.getParameter("formId"));
        SuperherosDao.deleteSuper(superherodelete);
        return "redirect:/superhero";
    }
    //Call a superherosdao method which will remove the object from ArrayList
    //It will also call a delete database method that will use jdbc to delete from MySQL DB

    @PostMapping("superheroEdit")
    public String editSuperhero(HttpServletRequest request) throws SQLException {
        int superheroField = Integer.parseInt(request.getParameter("formField"));
        int superheroFieldNum = Integer.parseInt(request.getParameter("formFieldNum"));
        String superheroFieldNew = request.getParameter("formFieldNew");
        SuperherosDao.editSuper(superheroFieldNum, superheroField, superheroFieldNew);
        return "redirect:/superhero";
    }
    //Call superhero method that will edit in ArrayList
    //It will also call a database method to edit in the MySQL DB

    @RequestMapping("")
    public String displayTenSightings(Model tensightingsmodel) {
        ArrayList<SightingsDao> TenSightings = new ArrayList<SightingsDao>();
        int sizeTen = SightingsDao.Sightings.size() - 10;
        if (sizeTen < 0) {
            sizeTen = 0;
        }

        for (int i = SightingsDao.Sightings.size()-1; i > sizeTen; i--) {
                TenSightings.add(SightingsDao.Sightings.get(i));
        }
        tensightingsmodel.addAttribute("tensightings", TenSightings);
        return "index";
    }
}