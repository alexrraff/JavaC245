package com.superhero;

import com.superhero.dao.LocationsDao;
import com.superhero.dao.SightingsDao;
import com.superhero.dao.SuperherosDao;
import com.superhero.database.DatabaseDao;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.sql.SQLException;
import java.util.Scanner;

import static com.superhero.dao.SuperherosDao.Superheros;
//Import the necessary classes

@SpringBootApplication
@SpringBootConfiguration
public class App {
    //Define as SpringBootApplication Main
    public static void main(String[] args) throws SQLException {
        SpringApplication.run(App.class, args);
        //Run App.class
        DatabaseDao db = new DatabaseDao();
        db.getAllSupers();
        db.getAllSightings();
        db.getAllLocations();
        db.getAllOrganizations();
        db.getAllSuperpowers();
        //Create database object and use it to load all the different DAOs using Methods
    }
}