package com.superhero.database;

import java.sql.SQLException;
import com.mysql.cj.jdbc.MysqlDataSource;
import com.superhero.dao.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.List;
//Import necessary classes

@Repository
public class DatabaseDao {
    public String dbURL = "jdbc:mysql://localhost:3306/superhero";
    public String dbUser = "root";
    public String dbPassword = "alexalex";
    //Set public variables for the mysql connection

    public DatabaseDao() {
    }

    public int createSuperhero(SuperherosDao newsuper) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "INSERT INTO superheros(idSuperhero, Name, Description, idSuperpower, idOrganization) VALUES(?,?,?,?,?);";
        return jdbcTemplate.update(sql, newsuper.idsuperhero, newsuper.name, newsuper.description, newsuper.idsuperpower, newsuper.idorganization);
        //Use SQL to create new row in db with the proper information
    }

    public int createSuperpower(int idSuperpower, int idSuperhero) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "INSERT INTO Superpowers(idSuperpower, idSuperhero) VALUES(?,?);";
        return jdbcTemplate.update(sql, idSuperpower, idSuperhero);
        //Use SQL to create new row in db with the proper information
    }

    public int createLocation(LocationsDao location) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "INSERT INTO Locations" +
                "(idLocation, Name, Description, AddressInfo, LatLon) VALUES(?,?,?,?,?);";
        return jdbcTemplate.update(sql, location.idlocation, location.name, location.description, location.addressinfo, location.latlon);
        //Use SQL to create new row in db with the proper information
    }

    public int createSuperpower(SuperpowersDao superpower) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "INSERT INTO superpowers" +
                "(idSuperpower, Description, Name) VALUES(?,?,?);";
        return jdbcTemplate.update(sql, superpower.idsuperpower, superpower.description, superpower.name);
        //Use SQL to create new row in db with the proper information
    }

    public int createSighting(SightingsDao sighting) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "INSERT INTO sightings" +
                "(idSighting, idSuperhero, idLocation, DateTime) VALUES(?,?,?,?);";
        return jdbcTemplate.update(sql, sighting.idsighting, sighting.idsuperhero, sighting.idlocation, sighting.datetime);
        //Use SQL to create new row in db with the proper information
    }

    public int createOrganization(OrganizationsDao organizationnew) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "INSERT INTO organizations" +
                "(idOrganization, Name, Address, ContactInfo) VALUES(?,?,?,?);";
        return jdbcTemplate.update(sql, organizationnew.idorganization, organizationnew.name, organizationnew.address, organizationnew.contactinfo);
        //Use SQL to create new row in db with the proper information
    }
    //Create Entries into Tables with proper columns and values

    public int deleteSuperhero(int deleteid) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "DELETE FROM superheros WHERE idSuperhero = ?;";
        return jdbcTemplate.update(sql, deleteid);
        //Use SQL to create new row in db with the proper information
    }
    //Use DELETE FROM with jdbc to delete entry based on idSuperhero

    public int editSuperhero(int ids, int choice, String fieldNew) throws SQLException {
        String sql;
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        System.out.println(choice);
        switch (choice) {
            case 1:
                sql = "UPDATE superheros SET Name = ? WHERE idSuperhero = ?;";
                System.out.println(choice);
                return jdbcTemplate.update(sql, fieldNew, ids);
            case 2:
                sql = "UPDATE superheros SET Description = ? WHERE idSuperhero = ?;";
                return jdbcTemplate.update(sql, fieldNew, ids);
            case 3:
                sql = "UPDATE superheros SET idSuperpower = ? WHERE idSuperhero = ?;";
                return jdbcTemplate.update(sql, Integer.parseInt(fieldNew), ids);
            case 4:
                sql = "UPDATE superheros SET idOrganization = ? WHERE idSuperhero = ?;";
                return jdbcTemplate.update(sql, Integer.parseInt(fieldNew), ids);
        }
        return 1;
    }
    //4 Cases depending on which Column user wants to edit
    //Parse Ints properly and use variable info from the controller

    public List<OrganizationsDao> getAllOrganizations() {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String SQL = "select * from organizations";

        return jdbcTemplate.query(SQL, new OrganizationMapper());
        //Use Row mapper to create a new Game object for each row
    }

    public List<SuperherosDao> getAllSupers() {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String SQL = "select * from superheros";

        return jdbcTemplate.query(SQL, new SuperheroMapper());
        //Use Row mapper to create a new Game object for each row
    }
    public List<SightingsDao> getAllSightings() {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String SQL = "select * from sightings";

        return jdbcTemplate.query(SQL, new SightingMapper());
        //Use Row mapper to create a new Game object for each row
    }

    public List<LocationsDao> getAllLocations() {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String SQL = "select * from locations";

        return jdbcTemplate.query(SQL, new LocationMapper());
        //Use Row mapper to create a new Game object for each row
    }

    public List<SuperpowersDao> getAllSuperpowers() {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String SQL = "select * from superpowers";

        return jdbcTemplate.query(SQL, new SuperpowerMapper());
        //Use Row mapper to create a new Game object for each row
    }
    //Make JDBC connection and select all from the proper table
    //Use the Mappers to create an object for each row found in a table

    private static final class SuperheroMapper implements RowMapper<SuperherosDao> {

        public SuperherosDao mapRow(ResultSet rs, int index) throws SQLException {
            SuperherosDao superhero = new SuperherosDao();
            superhero.setIDSuperhero(rs.getInt("idSuperhero"));
            superhero.setName(rs.getString("Name"));
            superhero.setDescription(rs.getString("Description"));
            superhero.setIDOrg(rs.getInt("idOrganization"));
            return superhero;
            //Create a new Game and use SQL to get the information for it
            //Use setters to assign info to object
        }
    }
    private static final class SightingMapper implements RowMapper<SightingsDao> {

        public SightingsDao mapRow(ResultSet rs, int index) throws SQLException {
            SightingsDao sighting = new SightingsDao();
            sighting.setIDSuperhero(rs.getInt("idSuperhero"));
            sighting.setIDLocation(rs.getInt("idLocation"));
            sighting.setDateTime(rs.getInt("Datetime"));
            sighting.setIDSighting(rs.getInt("idSighting"));
            return sighting;
            //Create a new Game and use SQL to get the information for it
            //Use setters to assign info to object
        }
    }

    private static final class LocationMapper implements RowMapper<LocationsDao> {

        public LocationsDao mapRow(ResultSet rs, int index) throws SQLException {
            LocationsDao location = new LocationsDao();
            location.setIDLocation(rs.getInt("idLocation"));
            location.setName(rs.getString("Name"));
            location.setDescription(rs.getString("Description"));
            location.setAddressInfo(rs.getString("AddressInfo"));
            location.setLatlon(rs.getString("LatLon"));
            return location;
            //Create a new Game and use SQL to get the information for it
            //Use setters to assign info to object
        }
    }

    private static final class OrganizationMapper implements RowMapper<OrganizationsDao> {

        public OrganizationsDao mapRow(ResultSet rs, int index) throws SQLException {
            OrganizationsDao organization = new OrganizationsDao();
            organization.setIDOrganization(rs.getInt("idOrganization"));
            organization.setName(rs.getString("Name"));
            organization.setAddress(rs.getString("Address"));
            organization.setContactinfo(rs.getString("ContactInfo"));
            return organization;
            //Create a new Game and use SQL to get the information for it
            //Use setters to assign info to object
        }
    }

    private static final class SuperpowerMapper implements RowMapper<SuperpowersDao> {

        public SuperpowersDao mapRow(ResultSet rs, int index) throws SQLException {
            SuperpowersDao superpower = new SuperpowersDao();
            superpower.setIDSuperpower(rs.getInt("idSuperpower"));
            superpower.setName(rs.getString("Name"));
            superpower.setDescription(rs.getString("Description"));
            return superpower;
            //Create a new Game and use SQL to get the information for it
            //Use setters to assign info to object
        }
    }
    //Mappers that implement RowMapper
    //They get either int or String from the proper SQL column
    //Create object and use setters to assign info from MySQL DB

}
