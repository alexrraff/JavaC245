import java.util.ArrayList;
import java.io.*;
//Import classes for methods

public class DVD {
    public static ArrayList<DVD> DVDs = new ArrayList();
    //Create ArrayList to hold all the DVDs

    String director, studio, title, userRating, mPAA, releaseDate;
    //Declare string variables for the information on each DVD

    DVD(String t, String d, String s, String rD, String mP, String uR){
        this.releaseDate = rD;
        this.mPAA = mP;
        this.director = d;
        this.studio = s;
        this.title = t;
        this.userRating = uR;
        DVDs.add(this);
    }
    //DVD object constructor that creates DVD object with arguments
    //Adds the DVD Object to the DVD ArrayList

    public String getTitle() {
        return this.title;
    }
    public String getStudio() {
        return this.studio;
    }
    public String getDirector() {
        return this.director;
    }
    public String getRelease() {
        return this.releaseDate;
    }
    public String getUR() {
        return this.userRating;
    }
    public String getMPAA() {
        return this.mPAA;
    }
    //Create getters to get specific information from each DVD Object


    public String getLine() {
        String line = this.title + "," + this.director + "," + this.studio + "," + this.releaseDate + "," + this.mPAA + "," + this.userRating;
        return line;
    }
    //Getters that get all the information from the DVD Object
    //Creates a string of information and returns it

    public void setTitle(String tit) {
        this.title = tit;
    }
    public void setDirector(String dir) {
        this.director = dir;
    }
    public void setStudio(String stu) {
        this.studio = stu;
    }
    public void setRelease(String rel) {
        this.releaseDate = rel;
    }
    public void setMPAA(String mP) {
        this.mPAA = mP;
    }
    public void setUR(String ur) {
        this.userRating = ur;
    }
    //Setters that set the information for each variable of DVD Object

}

