import java.util.*;
import java.io.*;
//Import classes for methods

public class Main {
    static int built = 0;
    //Static int to see if the library has been loaded
    public static void main(String[] args) {

        String choice;
        //Sting variable for choice of user from main menu

        if (built == 0) {
            //If the library has not been loaded into ArrayList
            try {
                Scanner mainScanner = new Scanner(new BufferedReader(new FileReader("./src/DVDLibrary.txt")));
                //Create new scanner that reads the library text file

                while (mainScanner.hasNextLine()) {
                    String currentLine = mainScanner.nextLine();
                    String[] dvdArray = currentLine.split(",", 0);
                    DVD dvdAdd = new DVD(dvdArray[0], dvdArray[1], dvdArray[2], dvdArray[3], dvdArray[4], dvdArray[5]);
                }
                //While text file has next line
                //Split Line into String Array by using comma as seperator
                //Create a new Dvd object with each of the elements of the string array
                //While loops over all the lines of file creating new DVD object for each line

            } catch (Exception e) {

            }
            // try/catch for the file reader to work properly

            built = 1;
            //Assign built to 1 because the DVD Library has already been loaded

            System.out.println("\nWelcome to DVD Library 1.0!");
            //Print out welcome the first time the application is executed
        }

        while (0 < 1) {
            //Loop infinitely until loop is broken

            Scanner inpObj = new Scanner(System.in);
            // Create a Scanner object to read user's selection from main menu

            System.out.println("- Enter Add to Add a DVD");
            System.out.println("- Enter Remove to Remove a DVD");
            System.out.println("- Enter Edit to Edit a DVD");
            System.out.println("- Enter List to List all DVDs");
            System.out.println("- Enter Display to Get the Details of a DVD");
            System.out.println("- Enter Search to Search for a DVD");
            System.out.println("- Enter Save to Save All Changes");
            System.out.println("- Enter Quit to Save and Quit");
            choice = inpObj.nextLine();
            //List all the Main Menu Options
            //User's choice is next line input

            switch (choice) {
                case "Quit":
                    Actions.save();
                    System.exit(0);
                    //Invoke save method to save changes to ArrayList to the DVD Library .txt file
                    //System.exit(0) to end the application
                case "Save":
                    Actions.save();
                    break;
                case "Add":
                    Actions.add();
                    break;
                case "Remove":
                    Actions.remove();
                    break;
                case "Edit":
                    Actions.edit();
                    break;
                case "List":
                    Actions.list();
                    break;
                case "Display":
                    Actions.search();
                    break;
                case "Search":
                    Actions.search();
                    break;
            }
            //Switch for the user's input of the main menu
            //Invokes methods from Actions class that match user's choice
        }
    }

}