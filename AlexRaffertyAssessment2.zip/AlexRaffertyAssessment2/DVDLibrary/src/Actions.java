import java.time.LocalDate;
import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
//Import methods from java classes
public class Actions {
    public static void add() {
        Scanner inpObj = new Scanner(System.in);
        // Create a Scanner object for User Input of DVD to Add

        System.out.print("Enter DVD's Title: ");
        String t = inpObj.nextLine();
        t = t.replaceAll(",","");
        System.out.print("Enter DVD's Director: ");
        String d = inpObj.nextLine();
        d = d.replaceAll(",","");
        System.out.print("Enter DVD's Studio: ");
        String s = inpObj.nextLine();
        s = s.replaceAll(",","");
        System.out.print("Enter DVD's Release Date: ");
        String rD = inpObj.nextLine();
        System.out.print("Enter DVD's MPAA Rating: ");
        String mP = inpObj.nextLine();
        mP = mP.replaceAll(",","");
        System.out.print("Enter DVD's User Rating: ");
        String uR = inpObj.nextLine();
        uR = uR.replaceAll(",","");
        //Ask user for particular DVD input
        //Create String of the next line the user inputs
        //Replace all commas with nothing for proper storage in the DVDLibrary .txt file

        DVD dvdCreate = new DVD(t,d,s,rD,mP,uR);
        //Create DVD Object with the DVD Input

        System.out.println("DVD Added.");
        System.out.println("");
        //Print out DVD Added and add blank line

    }
    public static void remove(){

        Scanner inpObj = new Scanner(System.in);
        // Create a Scanner object to get DVD Remove input

        String replace = "";
        //replace will hold the new user's new input for the edit

        while (0 < 1) {
            //Loop infinitely until loop is broken

            System.out.print("Enter DVD's Title to Remove or Enter Return to Return to Main Menu: ");
            String removeT = inpObj.nextLine();
            //Ask for Title of DVD to edit or Return to Stop Edit and assign user's input to removeT

            if (removeT.equals("Return")) {
                break;
            }
            //If statement to see if user entered return then invoke Main.main() to return to Main Menu

            for (int i = 0; i < DVD.DVDs.size(); i++) {
                if (DVD.DVDs.get(i).getTitle().equals(removeT)) {
                    DVD.DVDs.remove(i);
                    System.out.println("DVD Removed.");
                    System.out.println("");
                    Main.main(null);
                }
            }
            //For loop through all the DVD objects of the DVDs ArrayList
            //If the title of DVD object matches the user input then remove object from ArrayList
            //And print out DVD Removed message
            //And invoke Main.main() to return to Main Menu and end while loop

            System.out.println("DVD Not Found.");
            //Print out DVD Not Found message if no DVD was found to remove
            //And continue the loop
        }

        /* try {
            Scanner sc = new Scanner(new BufferedReader(new FileReader("./src/DVDLibrary.txt")));
            Path filePath = Path.of("./src/DVDLibrary.txt");

            String fileAll = Files.readString(filePath);
            fileAll = fileAll.replaceAll(replace, "");
            fileAll = fileAll.replaceAll("(?m)^[ \t]*\r?\n", "");

            PrintWriter pw = new PrintWriter("./src/DVDLibrary.txt");
            pw.print(fileAll);
            pw.flush();
            pw.close();

        } catch (Exception e) {

        }

        This block of code was to remove a DVD from the DVD Library .txt file
        The file would be read into a string.  Then the part of the string matching the DVD
        would be replaced with nothing.
        Then then any empty lines would be replaced with nothing.
        Then the edited string would be written back to the file, flushed, and closed.
         */

    }
    public static void edit(){
        Scanner inpEdit = new Scanner(System.in);
        // Create a Scanner object for user input

        int indexEdit = 0, editLoop = 1;
        int dvdsSize = DVD.DVDs.size();
        //Create indexEdit to hold the index of DVDs ArrayList matching DVD to edit
        //editLoop holds int to decide if DVD not found and needs to loop again

        String newEdit, eChoice = "", origEdit = "";
        //Strings the hold the new edit info and the original unedited info;

        while (editLoop == 1) {
            //Loop while editLoop is 1

            System.out.print("Enter DVD's Title to Edit or Enter Return to Return to Main Menu: ");
            String editTitle = inpEdit.nextLine();
            //Ask user for DVD Title to Edit Object or Return to Return to Main Menu
            //editTitle is the input of the user

            for(int i = 0; i < DVD.DVDs.size(); i++) {
                //Loop through all the DVD objects of DVDs ArrayList

                if (editTitle.equals("Return")) {
                    Main.main(null);
                }
                //If user enters Return then invoke Main.main() to return to Main Menu

                if (DVD.DVDs.get(i).getTitle().equals(editTitle)) {
                    System.out.print("|Title: " + DVD.DVDs.get(i).getTitle());
                    System.out.print(" |Director: " + DVD.DVDs.get(i).getDirector());
                    System.out.print(" |Studio: " + DVD.DVDs.get(i).getStudio());
                    System.out.print(" |Release Date: " + DVD.DVDs.get(i).getRelease());
                    System.out.print(" |MPAA: " + DVD.DVDs.get(i).getMPAA());
                    System.out.println(" |User Rating: " + DVD.DVDs.get(i).getUR());
                    System.out.println("");
                    indexEdit = i;
                    editLoop = 0;

                    //origEdit = DVD.DVDs.get(indexEdit).getLine();//
                    //origEdit was DVDLibrary .txt file line matching the object
                }
                //If user input matches current object of DVD ArrayList then
                //And Display the DVD Objects info
                //and Get the index number of object and assign to indexEdit
                //And Assign 0 to editLoop to stop while loop
            }

            if (editLoop == 1) {
                System.out.println("DVD Not Found");
            }
            //If editLoop is 1 then no DVD was found and prints out message
            //This continues while loop to search for DVD to edit or allows for Return to Main Menu
        }

        System.out.println("What do you want to edit?");
        System.out.print("Enter 'Title', 'Director', 'Studio', 'ReleaseDate', 'MPAA', or 'UserRating' to Edit: ");
        eChoice = inpEdit.nextLine();
        //Ask user what to edit and give input options to edit it
        //Assign user's selection to eChoice

        switch (eChoice) {
            case "Title":
                System.out.print("Enter new Title: ");
                newEdit = inpEdit.nextLine();
                newEdit = newEdit.replaceAll(",","");
                DVD.DVDs.get(indexEdit).setTitle(newEdit);
                System.out.println("DVD Edited.");
                System.out.println("");

                /* try {
                    String changedEdit = DVD.DVDs.get(indexEdit).getLine();

                    Scanner sc = new Scanner(new BufferedReader(new FileReader("./src/DVDLibrary.txt")));
                    Path filePath = Path.of("./src/DVDLibrary.txt");

                    String fileAll = Files.readString(filePath);
                    fileAll = fileAll.replaceAll(origEdit, changedEdit);

                    PrintWriter pw = new PrintWriter("./src/DVDLibrary.txt");
                    pw.print(fileAll);
                    pw.flush();
                    pw.close();

                } catch (Exception e) {

                }
                I had this block of code in each switch case
                It got the current info and replaced it with the edited info
                It would then write the updated DVD Library to the .txt file
                */

                break;

                //Ask for the new title and assign to newEdit then replace all commas with nothing
                //Invoke setTitle from Actions class to assign new title to DVD Object with indexEdit
                //Message the user that the DVD was edited and break the switch

            case "Director":
                System.out.print("Enter new Director: ");
                newEdit = inpEdit.nextLine();
                newEdit = newEdit.replaceAll(",","");
                DVD.DVDs.get(indexEdit).setDirector(newEdit);
                System.out.println("DVD Edited.");
                System.out.println("");
                break;

            //Ask for the new director and assign to newEdit then replace all commas with nothing
            //Invoke setDirector from Actions class to assign new director to DVD Object with indexEdit
            //Message the user that the DVD was edited and break the switch

            case "Studio":
                System.out.print("Enter new Studio: ");
                newEdit = inpEdit.nextLine();
                newEdit = newEdit.replaceAll(",","");
                DVD.DVDs.get(indexEdit).setStudio(newEdit);
                System.out.println("DVD Edited.");
                System.out.println("");
                break;

            //Ask for the new studio and assign to newEdit then replace all commas with nothing
            //Invoke setStudio from Actions class to assign new studio to DVD Object with indexEdit
            //Message the user that the DVD was edited and break the switch

            case "ReleaseDate":
                System.out.print("Enter new Release Date: ");
                newEdit = inpEdit.nextLine();
                newEdit = newEdit.replaceAll(",","");
                DVD.DVDs.get(indexEdit).setRelease(newEdit);
                System.out.println("DVD Edited.");
                System.out.println("");
                break;

            //Ask for the new Release Date and assign to newEdit then replace all commas with nothing
            //Invoke setRelease from Actions class to assign new release date to DVD Object with indexEdit
            //Message the user that the DVD was edited and break the switch

            case "MPAA":
                System.out.print("Enter new MPAA: ");
                newEdit = inpEdit.nextLine();
                newEdit = newEdit.replaceAll(",","");
                DVD.DVDs.get(indexEdit).setMPAA(newEdit);
                System.out.println("DVD Edited.");
                System.out.println("");
                break;

            //Ask for the new MPAA Rating and assign to newEdit then replace all commas with nothing
            //Invoke setMPAA from Actions class to assign new MPAA to DVD Object with indexEdit
            //Message the user that the DVD was edited and break the switch

            case "UserRating":
                System.out.print("Enter new User Rating: ");
                newEdit = inpEdit.nextLine();
                newEdit = newEdit.replaceAll(",","");
                DVD.DVDs.get(indexEdit).setUR(newEdit);
                System.out.println("DVD Edited.");
                System.out.println("");
                break;

            //Ask for the new User Rating and assign to newEdit then replace all commas with nothing
            //Invoke setUR from Actions class to assign new User Rating to DVD Object with indexEdit
            //Message the user that the DVD was edited and break the switch

            default:
                System.out.println("No proper edit selection entered.");
                System.out.println("");

            //Default case is that no user selection matched the list and message the user

        }
    }
    public static void search(){
        Scanner inpSearch = new Scanner(System.in);
        // Create a Scanner object for user input

        int searchLoop = 1, indexSearch;
        //Declare loop int and the index of found object in ArrayList

        while (searchLoop == 1) {
            System.out.print("Enter DVD's Title to Edit or Return to Main Menu: ");
            String searchTitle = inpSearch.nextLine();
            //Ask user to enter title or return to return to Main Menu
            //Assign user input to searchTitle

            if (searchTitle.equals("Return")) {
                Main.main(null);
            }
            //If user enters Return then invoke Main.main to return to Main Menu

            for(int i = 0; i < DVD.DVDs.size(); i++) {
                if (DVD.DVDs.get(i).getTitle().equals(searchTitle)) {
                    System.out.println("DVD Found:");
                    System.out.print("|Title: " + DVD.DVDs.get(i).getTitle());
                    System.out.print(" |Director: " + DVD.DVDs.get(i).getDirector());
                    System.out.print(" |Studio: " + DVD.DVDs.get(i).getStudio());
                    System.out.print(" |Release Date: " + DVD.DVDs.get(i).getRelease());
                    System.out.print(" |MPAA: " + DVD.DVDs.get(i).getMPAA());
                    System.out.println(" |User Rating: " + DVD.DVDs.get(i).getUR());
                    System.out.println("");
                    searchLoop = 0;
                }
            }
            //Loop through all DVD Objects in the ArrayList
            //If any DVDs match the title then display their information
            //Assign 0 to searchLoop so stops looping the search

            if (searchLoop == 1) {
                System.out.println("DVD Not Found");
            }
            //If DVD is not found and searchLoop still equals 1 then
            //Message user DVD Not Found
        }
    }
    //Loop will continue as long as searchLoop is still 1 and not changed to 0 from a successful search
    public static void list(){
        System.out.println("DVDs:");
        for(int i = 0; i < DVD.DVDs.size(); i++) {
            System.out.print("|Title: " + DVD.DVDs.get(i).getTitle());
            System.out.print(" |Director: " + DVD.DVDs.get(i).getDirector());
            System.out.print(" |Studio: " + DVD.DVDs.get(i).getStudio());
            System.out.print(" |Release Date: " + DVD.DVDs.get(i).getRelease());
            System.out.print(" |MPAA: " + DVD.DVDs.get(i).getMPAA());
            System.out.println(" |User Rating: " + DVD.DVDs.get(i).getUR());
        }
        //Loop through all the DVD objects of DVDs ArrayList
        //Display all their information

        System.out.println("");
        Main.main(null);
        //Make a blank space and invoke Main.main() to Return to Main Menu

    }

    public static void save(){
        try {
            Scanner save = new Scanner(new BufferedReader(new FileReader("./src/DVDLibrary.txt")));
            //Create new scanner object of DVDLibrary.txt for reading

            Path filePath = Path.of("./src/DVDLibrary.txt");
            String fileAll = Files.readString(filePath);
            PrintWriter pw = new PrintWriter("./src/DVDLibrary.txt");
            //Create file path of the DVDLibrary and
            //Declare and assign fileAll string all the contents of the DVDLibrary .txt file
            //Create printWriter of the file

            LocalDate currentDate = LocalDate.now();
            //Create a date object and assign it to the current date

            String newFileName = "./src/DVDLibrary" + currentDate + ".txt";
            File newFile = new File(newFileName);
            //Create a new file that has DVDLibrary and the current date as the name

            if(!newFile.exists()) {
                PrintWriter npw = new PrintWriter(newFileName);
                npw.print(fileAll);
                npw.flush();
                npw.close();
            }
            //If the file already doesn't exist
            //Write all the current DVDLibrary to the new DVD Library with date
            //Flush and close it

            for(int i = 0; i < DVD.DVDs.size(); i++) {
                pw.print(DVD.DVDs.get(i).getTitle() + ",");
                pw.print(DVD.DVDs.get(i).getDirector() + ",");
                pw.print(DVD.DVDs.get(i).getStudio() + ",");
                pw.print(DVD.DVDs.get(i).getRelease() + ",");
                pw.print(DVD.DVDs.get(i).getMPAA() + ",");
                pw.println(DVD.DVDs.get(i).getUR());
            }
            //Loop through the DVDs ArrayList and write all its information to the new DVD Library .txt file

            pw.flush();
            pw.close();
            //Flush and close PrintWriter for new file

        } catch (Exception e) {

        }

        System.out.println("Library Saved.");
        System.out.println("");
        //Message user that the library was saved and add empty line
    }

}
