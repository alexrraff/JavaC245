import java.util.Scanner;
import java.util.Random;
// Import Java classes for Random function and Scanner

public class Main {
    static int playAgain = 1;
    //Variable to hold 1 to play again or 0 to not play again
    //Declare it outside methods and static so all methods can use it

    public static void main(String[] args) {

        Scanner myPlay = new Scanner(System.in);
        // Create a Scanner object

        while (playAgain == 1) {
            //playagain starts as 1 so it will run the first time

            play();
            //Invoke the play() method

            if (playAgain == 0) {
                //Check to see if playagain is set to 0 by a round input error
                //If so then don't give option to play again

            } else {
                //If no round input error than ask to play again after play() is finished

                System.out.println("Enter 1 to play again, type 0 to stop playing");
                //Display after the first game

                playAgain = myPlay.nextInt();
                //Get nextInt using scanner and assign to playagain
            }
            if (playAgain == 0) {
                System.out.println("Thanks for playing!");
                break;
                //If user inputs 0 for playagain then Printout Thanks and Break the While Loop
                //Breaking the while loop will end the game
            }
        }
    }

    static void play() {
        //play method with no return and no input variables

        int uWin = 0, tie = 0, cWin = 0, roundCounter = 0, numRounds = 0;
        //declare uWin - userwins, cWin - computerwins, tie - ties between user and computer
        //declare roundCounter - is how many round have been played
        //declare numRounds - the number of rounds the user wnats to play
        //declare all to 0

        Scanner myObj = new Scanner(System.in);
        // Create a Scanner object

        System.out.println("How many rounds from 1-10 would you like to play?");
        numRounds = myObj.nextInt();
        //Ask user how many rounds and get nextInt using scanner class
        //Assign the next integer to numRounds

        if(numRounds < 1 || numRounds > 10) {
            //If number of rounds selected by user is less than 1 or greater than 10
            //Display error
            //Set playagain to 0 so it does not ask to play again
            System.out.println("Error: You must select from 1-10");
            playAgain = 0;

            return;
            //return to end the play() method;
        }

        for (roundCounter = 1; roundCounter <= numRounds; roundCounter++) {
        //for loop that loops from 0 to the number of rounds the user wants to play
        //Start from 1 until equal to the num of rounds wanted to be played
        //Increase the round counter every for loop

                System.out.println("Enter 1 for Rock, Enter 2 for Paper, or Enter 3 for Scissors");
                int choice = myObj.nextInt();
                //Tell user the choices for the game
                //Declare choice - choice of the user for the game
                //Get the nextInt using scanner class and assign it to choice

                Random random = new Random();
                //Create random object using the scanner class
                int compRand = random.nextInt(3);
                //Declare compRand - the random choice of the computer
                //Get the nextInt from the random method and assign it to compRand

                compRand += 1;
                //Increase compRand by 1 because originally it was random from 0-2
                //0 cannot be choice so now it will be 1-3

                if (compRand == 1) {
                    System.out.println(compRand + " - Rock");
                } else if (compRand == 2) {
                    System.out.println(compRand + " - Paper");
                } else if (compRand == 3) {
                    System.out.println(compRand + " - Scissors");
                }
                System.out.println(compRand);
                //Print out the computers choice

                if (choice == compRand) {
                    //First see if user and computer chose the same
                    //If so then increase amount of ties by 1
                    //Display its a tie
                    tie += 1;
                    System.out.println("It's a tie");
                } else if (choice == 1) {
                    //If not a tie then first see if user chose 1

                    if (compRand == 3) {
                        //If so then if computer chose 3, the user wins
                        //Increase amount of user wins by 1
                        //Display user wins
                        uWin += 1;
                        System.out.println("User wins");
                    } else {
                        //If so, then the computer wins because cannot be 1 (tie) then computer chose 2
                        //Increase amount of computer wins by 1
                        //Display computer wins
                        cWin += 1;
                        System.out.println("Computer wins");
                    }
                } else if (choice == 2) {
                    //If not a tie then first see if user chose 2

                    if (compRand == 1) {
                        //If so then if computer chose 1, the user wins
                        //Increase amount of user wins by 1
                        //Display user wins
                        uWin += 1;
                        System.out.println("User wins");
                    } else {
                        //If so, then the computer wins because cannot be 2 (tie) then computer chose 3
                        //Increase amount of computer wins by 1
                        //Display computer wins
                        cWin += 1;
                        System.out.println("Computer wins");
                    }
                } else if (choice == 3) {
                    //If not a tie then first see if user chose 3

                    if (compRand == 2) {
                        //If so then if computer chose 2, the user wins
                        //Increase amount of user wins by 1
                        //Display user wins
                        uWin += 1;
                        System.out.println("User wins");
                    } else {
                        //If so, then the computer wins because cannot be 3 (tie) then computer chose 1
                        //Increase amount of computer wins by 1
                        //Display computer wins
                        cWin += 1;
                        System.out.println("Computer wins");
                    }
                } else {
                    //If all above if statements failed then user didn't enter 1, 2, or 3
                    //And the computer wins
                    //Display computer wins

                    System.out.println("You didn't enter 1, 2, or 3");
                    System.out.println("Computer wins");
                    //Display error message

                    cWin += 1;
                    //Increase amount of computer wins by 1

                }
            }

            System.out.println("User wins: " + uWin);
            System.out.println("Computer wins: " + cWin);
            System.out.println("Ties: " + tie);
            //This is after the for loop of rounds ends
            //Display amount of user wins, computer wins, and ties

            if (uWin > cWin) {
                System.out.println("The user is the winner\n");
            } else if (cWin > uWin) {
                System.out.println("The computer is the winner\n");
            } else {
                System.out.println("The user and the computer tied\n");
            }
            //If statement to see if amount of user wins was greater, fewer, or equal to computer wins
            //If uWin or cWin was not greater else then they are equal and tied
            //Display the appropriate info about if user or computer wins was greater or tied
    }
}