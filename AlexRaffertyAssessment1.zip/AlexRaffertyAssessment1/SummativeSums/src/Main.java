
public class Main {

    public static void main(String[] args) {
        int[] arr1 = { 1, 90, -33, -55, 67, -16, 28, -55, 15 };
        int[] arr2 = { 999, -60, -77, 14, 160, 301 };
        int[] arr3 = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200, -99 };
        //Declare 3 integer arrays and name arr1, arr2, and arr3
        //Assign each the integers required from the assessment

        System.out.println("#1 Array Sum: " + addarr(arr1));
        //Print out the sum of arr1 by invoking addarr with arr1 as the input argument
        System.out.println("#2 Array Sum: " + addarr(arr2));
        //Print out the sum of arr2 by invoking addarr with arr2 as the input argument
        System.out.println("#3 Array Sum: " + addarr(arr3));
        //Print out the sum of arr3 by invoking addarr with arr3 as the input argument
        //addarr() returns the sum so by invoking it will receive an integer sum of the array
    }
    public static int addarr(int[] arr) {
        //create static addarr method with int return and an int array input argument
            int arrTotal = 0;
            //Declare arrTotal - the sum total of the inputted array

            for (int i = 0; i < arr.length; i++) {
                //for loop that starts at i = 0 and goes until it is equal to the length of the array
                //each loop of the array i is increased by 1

                arrTotal += arr[i];
                //Call each element of the array using arr[i]
                //It will add each element to the current total of arrTotal
                //Add the end of the for loop it will be the sum of all the elements
            }

            return arrTotal;
            //return the integer arrTotal when the method is finished
    }
}