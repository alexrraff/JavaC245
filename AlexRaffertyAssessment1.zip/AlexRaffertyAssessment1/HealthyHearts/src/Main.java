import java.util.Scanner;
//Import scanner class for scanner object

public class Main {
    public static void main(String[] args) {

        System.out.print("What is your age? ");
        //Ask user what is their age

        Scanner myObj = new Scanner(System.in);
        //Create new scanner object

        double age = myObj.nextDouble();
        //Declare age - the age of the user
        //Assign the next user inputted number to age
        //Get a double to multiply it by a percent later

        double dHeartRate = 220 - age;
        //Declare dHeartRate which is maximum heartRate as a double
        int heartRate = (int)Math.round(dHeartRate);
        //Declare heartRate - the di
        // splayed maximum heartRate as int
        //Round the dHeartRate and convert it to integer for display

        System.out.println("Your maximum heart rate should be " + heartRate + " beats per minute.");
        //Display the maximum integer heart rate

        double dRandHeart1 = .85 * dHeartRate;
        //Declare dRandHeart1 - the maximum double heartRate multiplied by 85% as double

        int randHeart1 = (int)Math.round(dRandHeart1);
        //declare randHeart1 as integer
        //Round the dRandHeart1 and convert it to integer for display
        //assign to randHeart1

        double dRandHeart2 = .5 * dHeartRate;
        //Declare dRandHeart2 - the maximum double heartRate multiplied by 50% as double

        int randHeart2 = (int)Math.round(dRandHeart2);
        //declare randHeart1 as integer
        //Round the dRandHeart2 and convert it to integer for display
        //assign to randHeart2

        System.out.println("Your target HR Zone is  " + randHeart2 + " - " + randHeart1 + " beats per minute.");
        //Display the target heart rate zone using randHeart1 and randHeart2
    }
}
