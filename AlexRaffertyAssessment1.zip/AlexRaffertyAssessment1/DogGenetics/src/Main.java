import java.util.Scanner;
import java.util.Random;
//import scanner class for scanner object and random class for random function

public class Main {
    public static void main(String[] args) {
        int breedTotal = 100;
        //Declare breedTotal - the current percentage of dog's breed that is available for assigning

        System.out.print("What is your dog's name? ");
        //Ask user for their dogs name
        Scanner myObj = new Scanner(System.in);
        //Create new scanner object
        String name = myObj.nextLine();
        //Declare name - the name of the user's dog as a string
        //Assign the nextLine to the string name

        Random random = new Random();
        //Create random object
        int breed1 = random.nextInt(breedTotal + 1);
        //Declare breed1 integer - percentage of first breed of the total
        //Get next random integer from random method
        //The random number is from 0 - to the current breedTotal
        //Add 1 to the breedTotal to include the upperbound of breedTotal

        breedTotal -= breed1;
        //Subtract the breed1 percentage from breedTotal to get
        //the accurate remaining breed percentage

        if (breedTotal < 0) {
            breedTotal = 0;
        }
        //If breedTotal is negative then set it to 0

        int breed2 = random.nextInt(breedTotal + 1);
        //Declare breed2 integer - percentage of second breed of the total
        //Get next random integer from random method
        //The random number is from 0 - to the current breedTotal
        //Add 1 to the breedTotal to include the upperbound of breedTotal

        breedTotal -= breed2;
        //Subtract the breed2 percentage from breedTotal to get
        //the accurate remaining breed percentage

        if (breedTotal < 0) {
            breedTotal = 0;
        }
        //If breedTotal is negative then set it to 0

        int breed3 = random.nextInt(breedTotal + 1);
        //Declare breed3 integer - percentage of third breed of the total
        //Get next random integer from random method
        //The random number is from 0 - to the current breedTotal
        //Add 1 to the breedTotal to include the upperbound of breedTotal

        breedTotal -= breed3;
        //Subtract the breed3 percentage from breedTotal to get
        //the accurate remaining breed percentage

        if (breedTotal < 0) {
            breedTotal = 0;
        }
        //If breedTotal is negative then set it to 0

        int breed4 = random.nextInt(breedTotal + 1);
        //Declare breed4 integer - percentage of fourth breed of the total
        //Get next random integer from random method
        //The random number is from 0 - to the current breedTotal
        //Add 1 to the breedTotal to include the upperbound of breedTotal

        breedTotal -= breed4;
        //Subtract the breed2 percentage from breedTotal to get
        //the accurate remaining breed percentage

        if (breedTotal < 0) {
            breedTotal = 0;
        }
        //If breedTotal is negative then set it to 0

        int breed5 = breedTotal;
        //Declare breed5 integer - percentage of fifth breed of the total
        //breed5 will be breedTotal because it is the remaining available percentage
        //breed5 cannot be less than breedTotal or the breed percentages will not add up to 100

        System.out.print("Well then, I have this highly reliable report on " + name + "'s prestigious background right here.\n\n");
        System.out.print(name + " is:\n\n");
        //Display report information using the user dogs name

        System.out.print(breed1 + "% St. Bernard\n");
        System.out.print(breed2 + "% Chihuahua\n");
        System.out.print(breed3 + "% Dramatic RedNosed Asian Pug\n");
        System.out.print(breed4 + "% Common Cur\n");
        System.out.print(breed5 + "% King Doberman\n\n");
        //Display percentage of the five breeds using the breedX variables

        System.out.println("Wow, that's QUITE the dog!");
        //Display positive message to user
    }
}