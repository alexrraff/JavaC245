package org.vendingmachine;

public class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String errorMessage) {
        super(errorMessage);
    }
    //Exception when there is not enough money inserted to purchase item
}
