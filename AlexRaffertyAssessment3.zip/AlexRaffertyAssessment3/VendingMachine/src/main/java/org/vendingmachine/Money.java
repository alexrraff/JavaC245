package org.vendingmachine;

public class Money {
    public static double amount;
    //public double to hold amount of money inserted
    public static void setZero() {
        Money.amount = 0;
    }
    //method to set the amount of money to zero
}
