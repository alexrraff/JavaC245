package org.vendingmachine;

public class Change {
    //class to hold the amount of change coins
    public static int dollars, quarters, dimes, nickels, pennies;
    //public ints of each type of money for change
}
