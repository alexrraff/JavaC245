package org.vendingmachine;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import java.math.*;

public class View {

    public static void displayItems() {
        System.out.println("");
        System.out.println("Items:");
        int numbercounter = 1;
        for (int i = 1; i < Item.Items.size(); i++) {
            System.out.print("|Item: " + Item.Items.get(i).getName());
            System.out.print(" |Items Available: " + Item.Items.get(i).getNumber());
            System.out.format(" |Price: %.2f", Item.Items.get(i).getCost());
            System.out.println(" |Item Number: " + i);
        }
        System.out.println("");
        //For loop through all the objects of the Items ArrayList
        //Using the get methods of Item class get the information
        //Format the double to display price with 2 decimal places
    }

    public static boolean money() throws NoItemInventoryException, InsufficientFundsException {
        double insertMoney = 0;
        String insertMoneyS = "";
        //String to hold inputted amount or Exit word
        //Double to see if can successfully parse string to double

        Scanner inpObj = new Scanner(System.in);
        // Create a Scanner object to read user's selection from main menu

        System.out.println("- Enter Amount of Money Inserted or Enter Exit to Exit:");
        insertMoneyS = inpObj.nextLine();
        //Ask user for amount of money or exit

        if (insertMoneyS.equals("Exit")) {
            Service.write();
            System.exit(0);
        }
        //If user enters Exit then write the ArrayList to ItemList.txt file
        //Then exit the application

        try {
            insertMoney = Double.parseDouble(insertMoneyS);
            //Parse string to double to look for a wrong input with numberformatexception
            if (insertMoney < 0) {
                return false;
            }
            //If the user inserts a negative amount then return false and loop Main again
        } catch (NumberFormatException ex) {
            System.out.println("Incorrect Input");
            return false;
            //If the user inputs something that cannot be a double
            //Then return false and loop Main again
        }

        BigDecimal MoneyBD = new BigDecimal(insertMoney);
        MoneyBD = MoneyBD.setScale(2, RoundingMode.HALF_EVEN);
        Double money = MoneyBD.doubleValue();
        //Use BigDecimal to set the inputted amount to 2 decimal places and round down
        //Assign the money double to the value of the BigDecimal

        Service.amount(money);
        //Set the Money amount of Money Class to the formatted inputted amount
        return true;
    }

    public static void addMoney(int item) {
        double insertAddMoney = 0;
        double amountAddMoney = ((Item.Items.get(item).getCost() - Money.amount));
        String insertAddMoneyS;
        //amountAddMoney is the cost of item minus amount of currently inserted money
        //String and double to hold input as string then see if can parse to double

        Scanner inpObj = new Scanner(System.in);
        // Create a Scanner object to read user's selection from main menu

        System.out.print("- You Need to Add ");
        System.out.format("%.2f", amountAddMoney);
        //Ask for the needed amount with 2 decimal places
        System.out.println("");
        System.out.println("- Enter Amount of Money Added:");
        insertAddMoneyS = inpObj.nextLine();
        //Get string of inputted amount

        try {
            insertAddMoney = Double.parseDouble(insertAddMoneyS);
            //Try to parse or it will catch numberformatexception
            if (insertAddMoney < 0) {
                insertAddMoney = 0;
            }
            //If the user enters a correct double less than 0 then assign 0 to added money
        } catch (NumberFormatException ex) {
            System.out.println("Incorrect Input");
            insertAddMoney = 0;
            //If numberformatexception is caught then message incorrect input
            //Assign 0 to added money
        }

        BigDecimal AddMoneyBD = new BigDecimal(insertAddMoney);
        AddMoneyBD = AddMoneyBD.setScale(2, RoundingMode.HALF_EVEN);
        double addMoney = AddMoneyBD.doubleValue();
        //Use BigDecimal to correctly format the inputted amount to 2 decimal places and round down
        //declare addMoney and assign the correctly formatted money input

        Service.amount(addMoney);
        //Invoke amount() to add the correctly formatted money input to the amount in Money DAO
    }

    public static int chooseItem() {
        Scanner inpObj = new Scanner(System.in);
        // Create a Scanner object to read user's selection from main menu

        System.out.println("- Enter Item Number to Purchase:");
        int selection = 0;
        //User's item selection

        try {
            selection = inpObj.nextInt();
            //Try to get an int from user's item choice
        } catch (InputMismatchException ex) {
            System.out.println("Incorrect Input");
            return 999999999;
            //If the user's item choice couldn't become an int
            //Then print out error message
            //And return 999999999 to continue loop in Main.main()
        }
        return selection;
        //If the selection is read and is int then return it

    }

    public static void displayChange(int item) {
        System.out.println("Take " + Item.Items.get(item).getName());
        System.out.println("Your Change:");
        if (Change.dollars > 0) {
            System.out.print("|Dollars: " + Change.dollars);
        }
        if (Change.quarters > 0) {
            System.out.print(" |Quarters: " + Change.quarters);
        }
        if (Change.dimes > 0) {
            System.out.print(" |Dimes: " + Change.dimes);
        }
        if (Change.nickels > 0) {
            System.out.print(" |Nickels: " + Change.nickels);
        }
        if (Change.pennies > 0) {
            System.out.print(" |Pennies: " + Change.pennies);
        }
        //Tell user to take Item and then display change
        //Display amount of each coin if user is receiving at least 1 of each type of coin

        System.out.println("");
    }
}
