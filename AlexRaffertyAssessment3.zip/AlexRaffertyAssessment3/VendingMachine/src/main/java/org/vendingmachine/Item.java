package org.vendingmachine;

import java.util.ArrayList;
//Import ArrayList class

public class Item {
    String itemName;
    int numItems;
    double itemCost;
    //3 attributes of an Item for name, number of items, and cost

    public static ArrayList<Item> Items = new ArrayList();
    //Declare string variables for the information on each DVD

    Item(String iN, int nI, double iC){
        this.itemName = iN;
        this.numItems = nI;
        this.itemCost = iC;
        Items.add(this);
    }
    //Constructor that creates Item with name, number of items, and cost
    //Add this object to the Items ArrayList

    public String getName() {
        return this.itemName;
    }
    public int getNumber() {
        return this.numItems;
    }
    public double getCost() {
        return this.itemCost;
    }
    //3 Get Methods to return the name, number of items, and item cost
    //All with proper return data type
    public void setNumber(int num) {
        this.numItems = num;
    }
    //Set method to set the number of items remaining for an object
}
