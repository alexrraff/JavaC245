package org.vendingmachine;

public class NoItemInventoryException extends Exception {
    public NoItemInventoryException(String errorMessage) {
        super(errorMessage);
    }
    //Exception for when the item is sold out
}
