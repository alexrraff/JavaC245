package org.vendingmachine;

public class Main {

    public static void main(String[] args) throws InsufficientFundsException, NoItemInventoryException {
        //Declare Main with Exceptions

        Service.loadItemList();
        //Create objects of the ItemList.txt and Add to ArrayList from Service

        Service.amount(0);
        //Set money amount to 0

        while(1>0) {
            //While loop to run infinitely until Application is Exited

            View.displayItems();
            //List all the Item Information from View Class

            if (!View.money()) {
                continue;
            };
            //If Money returns false then continue loop to ask for Money to be inserted Again

            double money = Money.amount;
            //Get the amount of money stored in the Money DAO

            int item = View.chooseItem();
            //Get item number by invoking chooseItem from View Class

            try {
                if (item == 999999999 || !Service.itemCheck(item)) {
                    continue;
                };
                //If the itemCheck returns false then continue loop to list items and ask for money
                //If the item input is bad then Item will be 999999999 and will continue loop

                while (1 > 0) {
                    //Infinite loop until loop is broken by a successful check of enough money inserted
                    try {
                        Service.moneyCheck(item);
                        break;
                    } catch (InsufficientFundsException ex) {
                        View.addMoney(item);
                        //If the InsufficientFundsException is caught then
                        //Invoke addMoney to allow user to insert more money
                        //Will repeat until broken by a lack of exception
                    }
                }

                double change = Service.change(item);
                View.displayChange(item);
                Service.reduceInventory(item);
                Service.auditDAO(item, change);
                Money.setZero();
                //Get the change from Service.change and assign to change
                //Display the change by invoking method from View Class
                //Reduce inventory by 1
                //Invoke auditDAO to add a transaction record to AuditDAO.txt
                //Set the amount of money the user has inserted to 0

            } catch (NoItemInventoryException ex) {
                System.out.println("Item " + item + " is Sold Out.");
                System.out.println("Your change is " + Money.amount);
                Money.setZero();
                //If the item is sold out, display message to user
                //Return the inserted Money
                //Set Inserted Money Amount to 0
            }
        }


    }
}