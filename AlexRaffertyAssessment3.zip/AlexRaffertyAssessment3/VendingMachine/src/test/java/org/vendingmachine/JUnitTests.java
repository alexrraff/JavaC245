package org.vendingmachine;

import static org.junit.jupiter.api.Assertions.*;
import java.math.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
//Import the Test classes

class JUnitTests {

    static int testnumber = 1;
    //Set an item test number for all tests

    @BeforeAll
    public static void Loader(){
        Service.loadItemList();
    }
    //Load the ItemList into the ArrayList so tests can run

    @Test
    public void testEnough() {
        double enoughMoney = 12.73;
        double enoughPrice = Item.Items.get(testnumber).getCost();
        assertTrue(enoughMoney >= enoughPrice,"Enough Money");
        //Set an amount of money and assert responds true for money being more than price
    }

    @Test
    public void testItemNumber() {
        assertFalse( (testnumber < 1 || testnumber > (Item.Items.size() - 1)),"Item Number Valid");
        //Assert that testnumber is in 1 to the highest item number
    }

    @Test
    public void testCorrectChange() {
        Service.amount(12.73);
        double correctChange = (Money.amount - Item.Items.get(testnumber).getCost());
        Service.change(testnumber);
        //Set amount of money and set correctChange to the change from test item's price
        //Invoke change method to get the amount of change coins

        double addedChange = Change.dollars * (Coins.DOLLAR.getValue() * .01);
        addedChange += Change.quarters * (Coins.QUARTER.getValue() * .01);
        addedChange += Change.dimes * (Coins.DIME.getValue() * .01);
        addedChange += Change.nickels * (Coins.NICKEL.getValue() * .01);
        addedChange += Change.pennies * (Coins.PENNY.getValue() * .01);
        //Add the coin values all together to get how much money they are
        //Multiply by .01 to get the value down to cents

        BigDecimal addedChangeBD = new BigDecimal(addedChange);
        addedChangeBD= addedChangeBD.setScale(2, RoundingMode.HALF_UP);
        addedChange = addedChangeBD.doubleValue();
        //Use BigDecimal to make sure the added total value is rounded to 2 decimal places

        assertTrue( correctChange == addedChange,"Correct Change Given");
        //Assert that the value of all the coins is equal to correct amount of change
    }

    @Test
    public void testItemInventory() {
        assertTrue(Item.Items.get(testnumber).getNumber() > 0, "Enough Inventory");
        //Get the number of items left for test item and assert is greater than 0
    }

    @Test
    public void testPrice() {
        assertTrue(Item.Items.get(testnumber).getCost() > 0, "Correct Price");
        //Assert that the price of test item is greater than 0
    }
}