package org.vendingmachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;
import java.time.format.DateTimeFormatter;

@Component
public class ServiceImpl implements Service{
        //Implement ServiceImpl
        //And use all the objects from Context

        @Autowired
        public static void loadItemList() {
                try {
                        Scanner mainScanner = new Scanner(new BufferedReader(new FileReader("./src/main/java/org/vendingmachine/ItemList.txt")));
                        //Create new scanner that reads the ItemList .txt file

                        while (mainScanner.hasNextLine()) {
                                String currentLine = mainScanner.nextLine();
                                String[] itemArray = currentLine.split(",", 0);
                                ItemImpl itemImplAdd = new ItemImpl(itemArray[0], Integer.parseInt(itemArray[1]), Double.parseDouble(itemArray[2]));
                        }
                        //Continue loop through each line until there are no more lines
                        //Assign a string to the line being read
                        //Split the string by commas into an Array
                        //Create a new Item of the 3 pieces of information needed

                } catch (Exception e) {

                }
        }

        @Autowired
        public static boolean moneyCheck(int item, MoneyImpl moneyer) throws InsufficientFundsException {
                //Check if sufficient money with the InsufficientFundsException
                if (ItemImpl.itemImpls.get(item).getCost() > moneyer.amount) {
                        throw new InsufficientFundsException("Not Enough Money Inserted");
                        //If the amount of money inserted is less than the price
                        //Then throw exception with error message
                } else {
                        return true;
                        //If the inserted money in sufficient then return true
                }
        }

        @Autowired
        public static boolean itemCheck(int number) throws NoItemInventoryException {
                //Check if the item selected exists and is not sold out
                //Or throw NoItemInventoryException

                if (number < 1 || number > (ItemImpl.itemImpls.size() - 1)) {
                        System.out.println("Wrong Item Number");
                        return false;
                        //If the item number does not exist then return false

                } else if (ItemImpl.itemImpls.get(number).getNumber() == 0) {
                        throw new NoItemInventoryException("No Item Inventory");
                        //If the item is sold out then throw exception with error message
                } else {
                        return true;
                        //If item exists and is not sold out then return true
                }
        }

        @Autowired
        public static double change(int item, MoneyImpl moneyer, ChangeImpl changer, CoinsImpl coiner) {
                double allChange = 0;
                //Variable for the change amount and is initially 0

                if (moneyer.amount == ItemImpl.itemImpls.get(item).getCost()) {
                        System.out.println("No Change");
                        return allChange;
                        //If the amount of money inserted equals the price
                        //Then return the change amount of 0
                } else {
                        double changeD = moneyer.amount - ItemImpl.itemImpls.get(item).getCost();
                        //double change is money inserted minus cost of item
                        allChange = changeD;
                        //set the total change amount for return to changeD
                        changeD = changeD * 100;
                        //Times by 100 to get rid of decimals to be int
                        int change = (int)changeD;
                        //Assign change to the Inserted money minus the price


                        changer.dollars =  change / coiner.dollar;
                        //Set dollars of Change to change divided by Dollar Coins value
                        change = change % coiner.dollar;
                        //Do Change modulus Dollar Coins Value to create the remaining change amount

                        changer.quarters = change / coiner.quarter;
                        //Set quarters of Change to change divided by Quarter Coins value
                        change = change % coiner.quarter;
                        //Do Change modulus Quarter Coins Value to create the remaining change amount

                        changer.dimes = change / coiner.dime;
                        //Set dimes of Change to change divided by Dime Coins value
                        change = change % coiner.dime;
                        //Do Change modulus Dime Coins Value to create the remaining change amount

                        changer.nickels = change / coiner.nickel;
                        //Set nickels of Change to change divided by Nickel Coins value
                        change = change % coiner.nickel;
                        //Do Change modulus Nickel Coins Value to create the remaining change amount


                        changer.pennies = change;
                        //Set pennies of Change to the remaining change
                        return allChange;
                        //Return total amount of change
                }
        }

        @Autowired
        public static void reduceInventory(int number) {
                int changeInventory = ItemImpl.itemImpls.get(number).getNumber();
                //Get int of the number of items for Item Object in ArrayList
                if (changeInventory != 0) {
                        changeInventory -= 1;
                }
                //If the number of Items is not already 0 then reduce number of items by 1
                ItemImpl.itemImpls.get(number).setNumber(changeInventory);
                //Use set method from Item Class to set the new number of items for the object
        }

        @Autowired
        public static void auditDAO(int number, double change) {
                //Two arguments that are the new number of items and the amount of change received
                try {
                        FileWriter fw = new FileWriter("./src/main/java/org/vendingmachine/AuditDAO.txt", true);
                        BufferedWriter bw = new BufferedWriter(fw);
                        //Load AuditDAO.txt file and write to it by appending
                        try {
                                LocalDateTime datetime = LocalDateTime.now();
                                DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm / dd.MM.yy");
                                //Get Date and Time of Transaction
                                String formattedDate = datetime.format(myFormatObj);
                                //Format the date and time to be easier to read

                                bw.write(formattedDate + " - ");
                                bw.write(MoneyImpl.amount + ",");
                                String changeFormat = String.format("%.2f",change);
                                //Format double change to 2 decimal places
                                bw.write(changeFormat + " - ");
                                bw.write(ItemImpl.itemImpls.get(number).getName() + ",");
                                bw.write(ItemImpl.itemImpls.get(number).getNumber() + ",");
                                bw.write(ItemImpl.itemImpls.get(number).getCost() + "\n");
                                //For each transaction write the date, the inserted money amount, the change
                                //The Name, New Number of Items, and Cost of Item
                        } catch (Exception e) {

                        }

                        bw.flush();
                        bw.close();
                        //Flush and close to empty buffer and close file

                } catch (Exception e) {

                }
        }

        @Autowired
        public static void amount(double money, MoneyImpl moneyer) {
                moneyer.amount += money;
                //Accepts an argument of money and then is added to the amount of Money
                //In the Money DAO Class
        }

        @Autowired
        public static void write() {
                try {
                        Scanner save = new Scanner(new BufferedReader(new FileReader("./src/main/java/org/vendingmachine/ItemList.txt")));
                        //Create new scanner object of ItemList .txt for reading

                        PrintWriter pw = new PrintWriter("./src/main/java/org/vendingmachine/ItemList.txt");
                        //Create print writer object to write to ItemList. txt

                        ItemImpl.itemImpls.forEach( (n) -> {
                                pw.print(n.getName() + ",");
                                pw.print(n.getNumber() + ",");
                                pw.println(n.getCost());
                        } );
                        //Use Lambda to go to each object of the Items ArrayList
                        //For each object write the name, comma, number of items, comma, cost of item
                        //Use get methods to get information
                        //Write to the ItemList. txt

                        pw.flush();
                        pw.close();
                        //Flush buffer and close printwriter object

                } catch (Exception e) {

                }
        }

}

