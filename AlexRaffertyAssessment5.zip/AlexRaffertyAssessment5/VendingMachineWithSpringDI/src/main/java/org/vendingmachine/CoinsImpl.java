package org.vendingmachine;

import org.springframework.stereotype.Component;

@Component
public class CoinsImpl implements Coins{
    //class to hold the amount of change coins
    public static int dollar = CoinsENUM.DOLLAR.getValue();
    public static int quarter = CoinsENUM.QUARTER.getValue();
    public static int dime = CoinsENUM.DIME.getValue();
    public static int nickel = CoinsENUM.NICKEL.getValue();
    public static int penny = CoinsENUM.PENNY.getValue();
    //public ints of each type of money for change
    //Get the value of each coin by using CoinsENUM
}