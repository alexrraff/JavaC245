package org.vendingmachine;

import org.springframework.stereotype.Component;

public class NoItemInventoryException extends Exception {
    public NoItemInventoryException(String errorMessage) {
        super(errorMessage);
    }
    //Exception for when the item is sold out
}
