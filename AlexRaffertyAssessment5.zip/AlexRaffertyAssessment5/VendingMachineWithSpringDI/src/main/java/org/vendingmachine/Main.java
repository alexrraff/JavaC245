package org.vendingmachine;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

    public static void main(String[] args) throws NoItemInventoryException, InsufficientFundsException {
        AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext();
        appContext.scan("org.vendingmachine");
        appContext.refresh();
        //Create new AppContaxt and scan for beans and components

        ApplicationContext junitTestCTX = new ClassPathXmlApplicationContext("./src/main/java/resources/applicationContext.xml");
        JUnitTestsImpl jUnitTests = junitTestCTX.getBean("junittests", JUnitTestsImpl.class);
        //Get JUnitTest object form Context

        CoinsImpl coinController = appContext.getBean("coins", CoinsImpl.class);
        ChangeImpl changeController = appContext.getBean("change", ChangeImpl.class);
        MoneyImpl moneyController = appContext.getBean("money", MoneyImpl.class);
        ViewImpl viewController = appContext.getBean("view", ViewImpl.class);
        ServiceImpl serviceController = appContext.getBean("service", ServiceImpl.class);
        ItemController controller = appContext.getBean("controller", ItemController.class);
        //Create object for DAO's and Service,ItemController,and View from Context

        jUnitTests.Loader(serviceController);
        jUnitTests.testEnough();
        jUnitTests.testItemNumber();
        jUnitTests.testCorrectChange(serviceController,moneyController,changeController,coinController);
        jUnitTests.testItemInventory();
        jUnitTests.testPrice();
        //Perform JUnitTests from test object

        controller.vendingmachine(viewController, serviceController, moneyController, changeController, coinController);
        //Run the vendingmachine with the objects from Context
    }
}