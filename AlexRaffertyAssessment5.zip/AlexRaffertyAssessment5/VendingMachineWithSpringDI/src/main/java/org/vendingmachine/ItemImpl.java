package org.vendingmachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
//Import ArrayList class

@Component
public class ItemImpl implements Item {
    //Implement Item from Item Interface
    String itemName;
    int numItems;
    double itemCost;
    //3 attributes of an Item for name, number of items, and cost

    @Autowired
    public static ArrayList<ItemImpl> itemImpls = new ArrayList();
    //Declare string variables for the information on each DVD

    @Autowired
    public ItemImpl(String iN, int nI, double iC){
        this.itemName = iN;
        this.numItems = nI;
        this.itemCost = iC;
        itemImpls.add(this);
    }
    //Constructor that creates Item with name, number of items, and cost
    //Add this object to the Items ArrayList

    @Autowired
    public String getName() {
        return this.itemName;
    }
    @Autowired
    public int getNumber() {
        return this.numItems;
    }
    @Autowired
    public double getCost() {
        return this.itemCost;
    }
    //3 Get Methods to return the name, number of items, and item cost
    //All with proper return data type
    @Autowired
    public void setNumber(int num) {
        this.numItems = num;
    }
    //Set method to set the number of items remaining for an object
}
