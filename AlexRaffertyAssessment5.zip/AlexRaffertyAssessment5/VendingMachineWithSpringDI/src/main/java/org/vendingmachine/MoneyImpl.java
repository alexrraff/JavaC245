package org.vendingmachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MoneyImpl implements Money{
    //Implement from Money Interface
    public static double amount;
    //public double to hold amount of money inserted
    @Autowired
    public static void setZero() {
        MoneyImpl.amount = 0;
    }
    //method to set the amount of money to zero
}
