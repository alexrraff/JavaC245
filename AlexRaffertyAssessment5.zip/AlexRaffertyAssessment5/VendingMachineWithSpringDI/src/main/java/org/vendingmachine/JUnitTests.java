package org.vendingmachine;

public interface JUnitTests {
}
