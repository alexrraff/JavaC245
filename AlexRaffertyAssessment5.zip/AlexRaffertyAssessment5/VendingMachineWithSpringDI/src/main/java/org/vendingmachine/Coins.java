package org.vendingmachine;

public interface Coins {
}
