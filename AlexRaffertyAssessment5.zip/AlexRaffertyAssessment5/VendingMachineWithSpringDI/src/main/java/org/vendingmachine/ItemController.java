package org.vendingmachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ItemController {

    @Autowired
    public void vendingmachine(ViewImpl viewer, ServiceImpl servicer, MoneyImpl moneyer, ChangeImpl changer, CoinsImpl coiner) throws InsufficientFundsException, NoItemInventoryException {
        //Declare Main with the objects from Context and with Exceptions

        servicer.loadItemList();
        //Create objects of the ItemList.txt and Add to ArrayList from Service

        servicer.amount(0, moneyer);
        //Set money amount to 0

        while(1>0) {
            //While loop to run infinitely until Application is Exited

            viewer.displayItems();
            //List all the Item Information from View Class

            if (!viewer.money(servicer, moneyer)) {
                continue;
            };
            //If Money returns false then continue loop to ask for Money to be inserted Again

            double money = moneyer.amount;
            //Get the amount of money stored in the Money DAO

            int item = viewer.chooseItem();
            //Get item number by invoking chooseItem from View Class

            try {
                if (item == 999999999 || !servicer.itemCheck(item)) {
                    continue;
                };
                //If the itemCheck returns false then continue loop to list items and ask for money
                //If the item input is bad then Item will be 999999999 and will continue loop

                while (1 > 0) {
                    //Infinite loop until loop is broken by a successful check of enough money inserted
                    try {
                        servicer.moneyCheck(item, moneyer);
                        break;
                    } catch (InsufficientFundsException ex) {
                        viewer.addMoney(item, moneyer, servicer);
                        //If the InsufficientFundsException is caught then
                        //Invoke addMoney to allow user to insert more money
                        //Will repeat until broken by a lack of exception
                    }
                }

                double change = servicer.change(item, moneyer, changer, coiner);
                if (change != 0) {
                    viewer.displayChange(item, changer);
                } else if (change == 0) {
                    System.out.println("Take " + ItemImpl.itemImpls.get(item).getName());
                }
                servicer.reduceInventory(item);
                servicer.auditDAO(item, change);
                moneyer.setZero();
                //Get the change from Service.change and assign to change
                //Display the change by invoking method from View Class
                //Reduce inventory by 1
                //Invoke auditDAO to add a transaction record to AuditDAO.txt
                //Set the amount of money the user has inserted to 0

            } catch (NoItemInventoryException ex) {
                System.out.println("Item " + item + " is Sold Out.");
                System.out.println("Your change is " + moneyer.amount);
                moneyer.setZero();
                //If the item is sold out, display message to user
                //Return the inserted Money
                //Set Inserted Money Amount to 0
            }
        }


    }
}
