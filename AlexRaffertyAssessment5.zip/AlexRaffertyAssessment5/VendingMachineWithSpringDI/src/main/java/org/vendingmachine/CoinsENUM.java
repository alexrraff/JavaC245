package org.vendingmachine;

import org.springframework.beans.factory.annotation.Autowired;

public enum CoinsENUM {
    DOLLAR(100),QUARTER(25), DIME(10), NICKEL(5), PENNY(1);
    //value of each money times 100 to facilitate faster integer operations
    //Multiply later by .01 to get cents
    int value;
    //value of coin

    @Autowired
    CoinsENUM(int x) {
        this.value = x;
    }
    //Constructor of Coin with value x

    @Autowired
    public int getValue() {
        return value;
    }
    //Get method that returns value of Coin
}
