package org.vendingmachine;

import static org.junit.jupiter.api.Assertions.*;
import java.math.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
//Import the Test classes

@Component
class JUnitTestsImpl implements JUnitTests{
    //Edit all the methods to use the objects from Context
    static int testnumber = 1;
    //Set an item test number for all tests

    @BeforeAll
    @Autowired
    public static void Loader(){
        ServiceImpl.loadItemList();
    }
    //Load the ItemList into the ArrayList so tests can run

    @Test
    @Autowired
    public void testEnough() {
        double enoughMoney = 12.73;
        double enoughPrice = ItemImpl.itemImpls.get(testnumber).getCost();
        assertTrue(enoughMoney >= enoughPrice,"Enough Money");
        //Set an amount of money and assert responds true for money being more than price
    }

    @Test
    @Autowired
    public void testItemNumber() {
        assertFalse( (testnumber < 1 || testnumber > (ItemImpl.itemImpls.size() - 1)),"Item Number Valid");
        //Assert that testnumber is in 1 to the highest item number
    }

    @Test
    @Autowired
    public void testCorrectChange(MoneyImpl moneyer, ItemImpl itemer, ChangeImpl changer, CoinsImpl coiner) {
        ServiceImpl.amount(12.73, moneyer);
        double correctChange = (MoneyImpl.amount - ItemImpl.itemImpls.get(testnumber).getCost());
        ServiceImpl.change(testnumber, moneyer, changer, coiner);
        //Set amount of money and set correctChange to the change from test item's price
        //Invoke change method to get the amount of change coins

        double addedChange = changer.dollars * (coiner.dollar * .01);
        addedChange += changer.quarters * (coiner.quarter * .01);
        addedChange += changer.dimes * (coiner.dime * .01);
        addedChange += changer.nickels * (coiner.nickel * .01);
        addedChange += changer.pennies * (coiner.penny * .01);
        //Add the coin values all together to get how much money they are
        //Multiply by .01 to get the value down to cents

        BigDecimal addedChangeBD = new BigDecimal(addedChange);
        addedChangeBD= addedChangeBD.setScale(2, RoundingMode.HALF_UP);
        addedChange = addedChangeBD.doubleValue();
        //Use BigDecimal to make sure the added total value is rounded to 2 decimal places

        assertTrue( correctChange == addedChange,"Correct Change Given");
        //Assert that the value of all the coins is equal to correct amount of change
    }

    @Test
    @Autowired
    public void testItemInventory(ItemImpl itemer) {
        assertTrue(itemer.itemImpls.get(testnumber).getNumber() > 0, "Enough Inventory");
        //Get the number of items left for test item and assert is greater than 0
    }

    @Test
    @Autowired
    public void testPrice(ItemImpl itemer) {
        assertTrue(itemer.itemImpls.get(testnumber).getCost() > 0, "Correct Price");
        //Assert that the price of test item is greater than 0
    }


}