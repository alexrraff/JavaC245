package com.bcms;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@Controller
public class MainController {
    String postPassword, postName, postURL, postExpire;
    String password = "blogpassword", postContent, postTags;
    String createpassword = "createpassword";
    int postNumber;
    //Second create password just for Create Method
    //Regular password works for Create,Edit,Delete

    @RequestMapping("")
    public String displayPosts(Model postmodel) throws SQLException {
        if (Post.Posts.size() > 0) {
            Post.maintenance();
        }
        ArrayList<Post> ReversePosts = new ArrayList<Post>();
        for (int i = Post.Posts.size() - 1; i >= 0; i--) {
            ReversePosts.add(Post.Posts.get(i));
        }
        postmodel.addAttribute("posts", ReversePosts);
        return "index";
    }
    //If size of Posts ArrayList is greater than 0 then
    //Invoke maintenance() to remove posts past expiration date
    //RequestMapping for /
    //Creates ArrayList to read through Posts backwards and add to it
    //Adds to model

    @RequestMapping("manage")
    public String manage() {
        return "manage";
    }
    //Manage just has links doesn't need anything returned

    @RequestMapping("edit")
    public String displaysdfPosts(Model postsdfmodel) throws SQLException {
        postsdfmodel.addAttribute("posts", Post.Posts);
        return "test";
    }
    //Adds Post to Model

    @RequestMapping("editpost")
    public String displayEditpost(Model editpostmodel) {
        editpostmodel.addAttribute("posts", 1);
        return "editpost";
    }
    //Empty Model

    @RequestMapping("deletepost")
    public String displayDeletepost(Model deletepostmodel) {
        deletepostmodel.addAttribute("posts", 1);
        return "deletepost";
    }
    //Empty Model

    @RequestMapping("editsrc")
    public String displayEdits(Model editmodel) {
        editmodel.addAttribute("posts", Post.Posts);
        return "editsrc";
    }
    //Adds Posts to model

    @RequestMapping("deletesrc")
    public String deleteEdits(Model deletemodel) {
        deletemodel.addAttribute("posts", Post.Posts);
        return "deletesrc";
    }
    //Adds Posts to model

    @RequestMapping("edit/{postId}")
    public String displayEdit(Model editonemodel, @PathVariable String postId) {
        int intpostId = Integer.parseInt(postId) - 1;
        editonemodel.addAttribute("post", Post.Posts.get(intpostId));
        editonemodel.addAttribute("postnum", intpostId);
        return "edit";
    }
    //Uses Path Variable to get one Post using .get()
    //Adds it and path variable to model

    @RequestMapping("createpost")
    public String createpostpage(Model pagemodel) {
        return "createpost";
    }
    //Empty Model

    @PostMapping("editpostaction")
    public String editpost(HttpServletRequest request) throws SQLException {
        postPassword = request.getParameter("formPassword");
        if (postPassword.equals(password)) {
            try {
                postNumber = Integer.parseInt(request.getParameter("formNumber"));
            } catch (NumberFormatException e) {
                return "redirect:/";
            }
            postName = request.getParameter("formName");
            postContent = request.getParameter("formContent");
            postTags = request.getParameter("formTags");
            postURL = request.getParameter("formURL");
            postExpire = request.getParameter("formExpire");

            Post.Posts.get(postNumber).setName(postName);
            Post.Posts.get(postNumber).setContent(postContent);
            Post.Posts.get(postNumber).setTags(postTags);
            Post.Posts.get(postNumber).setURL(postURL);
            Post.Posts.get(postNumber).setExpire(postExpire);
            Post.Posts.get(postNumber).updateDb(postNumber);
        }
        return "redirect:/";
    }
    //If the password input equals password
    //Then get all form inputs and use them to set the object
    //Invoke updateDb to update Post in MySQL DB
    //If postNumber can't be parsed then redirect to index

    @PostMapping("createpostaction")
    public String createpost(HttpServletRequest request) throws SQLException, IOException {
        postPassword = request.getParameter("formPassword");
        if (postPassword.equals(password) || postPassword.equals(createpassword)) {
            postName = request.getParameter("formName");
            postContent = request.getParameter("formContent");
            postTags = request.getParameter("formTags");
            postURL = request.getParameter("formURL");
            postExpire = request.getParameter("formExpire");
            Post newpost = new Post();
            newpost.setName(postName);
            newpost.setContent(postContent);
            newpost.setTags(postTags);
            newpost.setURL(postURL);
            newpost.setExpire(postExpire);
            int ids = newpost.getID();
            newpost.addDb(ids);
        }
        return "redirect:/";
    }
    //If passsword input equals password or the the secodn password used to create
    //Then get the form inputs and create and set new post object
    //Invoke addDb to add it to the MySQL DB

    @PostMapping("deletepostaction")
    public String deletepost(HttpServletRequest request) throws SQLException, IOException {
        postPassword = request.getParameter("formPassword");
        if (postPassword.equals(password) || postPassword.equals(createpassword)) {
            try {
                postNumber = Integer.parseInt(request.getParameter("formNumber"));
            } catch (NumberFormatException e) {
                return "redirect:/";
            }
            postNumber -= 1;
            Post.deleteDb(postNumber);
            Post.Posts.remove(postNumber);
        }
        return "redirect:/";
    }
    //If password input matches password then get the post number
    //Invoke deleteDb to delete from MySQL DB
    //Then remove it from Posts ArrayList
    //If postNumber can't be parsed then redirect to index

}