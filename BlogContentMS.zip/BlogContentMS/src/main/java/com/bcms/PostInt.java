package com.bcms;

public interface PostInt {

    //Interface for Post Object Class
    public void setID(int id);
    public void setContent(String content);

    public void setName(String name);

    public void setTags(String tags);
    public void setURL(String url);

    public void setDateTime(String dt);
    public String getExpire();

    public int getID();
    public void setExpire(String ed);
    public String getContent();

    public String getName();

    public String getTags();
    public String getURL();

    public String getDateTime();
}
