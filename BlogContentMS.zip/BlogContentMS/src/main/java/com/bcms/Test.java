package com.bcms;

import org.junit.jupiter.api.BeforeAll;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(classes = Post.class)
public class Test {

    @BeforeAll
    public static void setUpClass() {
        DatabaseDao db = new DatabaseDao();
        db.getPosts();
    }

    @org.junit.jupiter.api.Test
    public void testAdd() throws SQLException {
        Post newpost = new Post();
        newpost.setID(999);
        newpost.setName("Name");
        newpost.setContent("Description");
        newpost.setTags("Tags");
        newpost.setURL("google.com");
        newpost.setExpire("2022-7-31");
        int newsh = Post.Posts.size() - 1;
        assertEquals(newpost, Post.Posts.get(newsh));
        Post.Posts.remove(newpost);
    }

    @org.junit.jupiter.api.Test
    public void testContains() throws SQLException {
        Post newpost = new Post();
        newpost.setID(999);
        newpost.setName("Name");
        newpost.setContent("Description");
        newpost.setTags("Tags");
        newpost.setURL("google.com");
        newpost.setExpire("2022-7-31");
        assertTrue(Post.Posts.contains(newpost));
        Post.Posts.remove(newpost);
    }
}
