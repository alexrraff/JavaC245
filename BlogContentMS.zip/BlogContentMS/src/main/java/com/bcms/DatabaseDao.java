package com.bcms;

import com.mysql.cj.jdbc.MysqlDataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class DatabaseDao {
    public String dbURL = "jdbc:mysql://localhost:3306/bcms";
    public String dbUser = "root";
    public String dbPassword = "alexalex";
    //JDBC MySQL Connect details

    public void Database() {
    }

    public int createPost(Post newpost) {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "INSERT INTO posts(id, name, tags, datetime, content, expiredate, imageurl) VALUES(?,?,?,?,?,?,?);";
        return jdbcTemplate.update(sql, newpost.id, newpost.name, newpost.tags, newpost.datetime, newpost.content, newpost.expiredate, newpost.imageURL);
        //Use SQL to create new row in db with the proper information
    }
    //Create post by inserting all data from Post Object into DB

    public int editPost(Post newpost) {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE posts SET name=?, tags=?, datetime=?, content=?, expiredate = ?, imageurl = ? WHERE id=?;";
        return jdbcTemplate.update(sql, newpost.name, newpost.tags, newpost.datetime, newpost.content, newpost.expiredate, newpost.imageURL, newpost.id);
        //Use SQL to create new row in db with the proper information
    }
    //Edit post by updating MySQL with Post Object

    public int deletePost(int deleteid) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "DELETE FROM posts WHERE id = ?;";
        return jdbcTemplate.update(sql, deleteid);
        //Use SQL to create new row in db with the proper information
    }
    //Delete Object using ID

    public List<Post> getPosts() {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String SQL = "select * from posts";

        return jdbcTemplate.query(SQL, new PostMapper());
        //Use Row mapper to create a new Game object for each row
    }
    //Use PostMapper() to retreive all posts from MySQL DB

    private static final class PostMapper implements RowMapper<Post> {

        public Post mapRow(ResultSet rs, int index) throws SQLException {
            Post newpost = new Post();
            newpost.setID(rs.getInt("id"));
            newpost.setName(rs.getString("name"));
            newpost.setTags(rs.getString("tags"));
            newpost.setDateTime(rs.getString("datetime"));
            newpost.setURL(rs.getString("imageurl"));
            newpost.setContent(rs.getString("content"));
            newpost.setExpire(rs.getString("expiredate"));
            return newpost;
            //Create a new Game and use SQL to get the information for it
            //Use setters to assign info to object
        }
        //PostMapper uses MySQL data and Post Setters to create and set new post object
    }
}

