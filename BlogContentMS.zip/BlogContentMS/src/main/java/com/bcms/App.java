package com.bcms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.sql.SQLException;


@SpringBootApplication
@SpringBootConfiguration
public class App {
    public static void main(String[] args) throws IOException, SQLException {
        SpringApplication.run(App.class, args);
        DatabaseDao db = new DatabaseDao();
        db.getPosts();
        //Spring boot and invoke database object to get all posts from MySQL DB
    }
}