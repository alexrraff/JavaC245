package com.bcms;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

@Repository
public class Post implements PostInt {
    public int id;
    public String name, tags, datetime, imageURL, content, expiredate;
    //Variables for Post Object
    public static ArrayList<Post> Posts = new ArrayList<Post>();
    //Create ArrayList to hold all Post Objects
    
    public Post() {
        int bignum;
        int bigid;
        if (Posts.size() != 0) {
            bignum = Posts.size() - 1;
            bigid = Posts.get(bignum).id;
            bigid += 1;
        } else {
            bigid = 1;
        }
        this.id = Posts.size();
        this.datetime = getNowDT();
        Posts.add(this);
    }
    //Get the id of the Post Object with highest index in ArrayList
    //Add 1 to it
    //If size of ArrayList is 0 then just set id to 1
    //Invoke getNowDT to set datetime to date/time of creation
    //Add Object to ArrayList

    public String getNowDT()
    {
        java.util.Date date = new java.util.Date();
        SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm z");
        String strDate = formatter.format(date);
        String returndate = strDate;
        return returndate;
    }
    //Get date/time with date object then set to pattern
    //Return string of date

    @Override
    public void setID(int id) {this.id = id;}
    @Override
    public void setExpire(String ed) {this.expiredate = ed;}
    @Override
    public String getExpire() {return this.expiredate;}
    @Override
    public void setName(String name) {this.name = name;}
    @Override
    public void setContent(String content) {this.content = content;}
    @Override
    public void setURL(String url) {this.imageURL = url;}
    @Override
    public void setTags(String tags) {this.tags = tags;}
    @Override
    public void setDateTime(String dt) {this.datetime = dt;}
    @Override
    public int getID() {return this.id;}
    @Override
    public String getContent() {return this.content;}
    @Override
    public String getURL() {return this.imageURL;}
    @Override
    public String getName() {return this.name;};
    @Override
    public String getTags() {return this.tags;}
    @Override
    public String getDateTime() {return this.datetime;};
    //Getters and setters for all variables of Post Object


    public static void addDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.createPost(Post.Posts.get(ids));
    };
    //Create db object and invoke createPost to create in MySQL DB

    public static void updateDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.editPost(Post.Posts.get(ids));
    };
    //Create db object and invoke updateDb to update in MySQL DB

    public static void deleteDb(int ids) throws SQLException {
        DatabaseDao db = new DatabaseDao();
        db.deletePost(Post.Posts.get(ids).id);
    };
    //Create db object and invoke deleteDb to delete in MySQL DB
    public static void maintenance() throws SQLException {
        LocalDate datenow = java.time.LocalDate.now();
        for (int i=0; i < Post.Posts.size(); i++) {
            String dateTimePattern = "yyyy-MM-dd";
            DateTimeFormatter formattercompare = DateTimeFormatter.ofPattern(dateTimePattern);
            try {
                LocalDate dateexpire = LocalDate.parse(Post.Posts.get(i).getExpire(), formattercompare);
                if (dateexpire.compareTo(datenow) < 0) {
                    DatabaseDao db = new DatabaseDao();
                    db.deletePost(i);
                    Post.Posts.remove(i);
                }
            } catch (NullPointerException e) {

            }
        }
    }
    //Use Try/Catch for a parse exception when there are no Post Objects in ArrayList
    //Maintenance method gets current date with localdate object
    //Gets the expiredate from Post Object and format it to get just date
    //Compares expire date to the current date
    //If the expire date has past then invoke deletePost to delete from MySQL DB
    //And .remove() it from ArrayList

}
