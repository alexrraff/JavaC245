package com.guess;

import org.springframework.stereotype.Repository;
import java.sql.SQLException;
import java.util.Arrays;

@Repository
public class Service {
    static public int rounds(GameDao game) throws SQLException {
        game.round += 1;
        Database db = new Database();
        db.addRound(game.id,game.round);
        return game.round;
    }
    //Method to increase the rounds of a game by 1 with it as input
    //Invoke database addRound to set the mysql round entry for it to the new correct amount
    //Return the amount as an int
    public static void loadGames() {
        Database db = new Database();
        db.loadGames();
    }
    //Create database object then use it to invoke loadGames

    static public int[] result(int[] testuser, GameDao newgame) {
        int[] testAnswerOriginal = {(newgame.answer/1000),(newgame.answer/100)%10,(newgame.answer/10)%10,(newgame.answer%10)};
        //Use division and modulus to break guess into 4 ints in an array
        int[] testAnswer = Arrays.copyOf(testAnswerOriginal,4);
        //Create new array and copy the answer array
        int[] testResult = {0,0,0,0,0,0};
        int exactCounter = 0;
        int partialCounter = 0;
        int[] partialAdd = new int[10];
        int addHolder;
        //Various variable to hold results, the amount of exacts/partials
        //An int array to hold partials for each digit

        for (int i = 0; i < testuser.length; i++) {
            for (int j = 0; j < 4; j++) {
                if (testuser[i] == testAnswer[j]) {
                    addHolder = testAnswer[j];
                    if (i == j) {;
                        exactCounter += 1;
                        testAnswer[j] = ' ';
                        //Remove an answer when it is found
                        //So no more partials can be found for it
                        partialAdd[addHolder] = 10;
                        testResult[i] = 2;
                        continue;
                    } else if (testResult[i] != 2 && partialAdd[addHolder] != 10){
                        partialAdd[addHolder] += 1;
                        testResult[i] = 1;
                    }
                }
            }
        }
        //Loop that goes through each guess integer
        //Nested loop that compares each guess integer to all ints of answers
        //If position is same then it is exact
        //If position is not then it is partial
        //If exact is found then set partialadd for that digit to 10 so cannot be partial digit
        //If only partials are found then increase number of partials for each of 0-9

        for(int i=0; i<partialAdd.length; i++){
            partialCounter += partialAdd[i];
        }
        //Loop through 0-9 and add amount of partials to get total amount of partials
        partialCounter = partialCounter % 10;
        //If partial counter gets any 10s from having an exact then
        //Use modulus to remove them to leave only single ints
        testResult[4] = exactCounter;
        testResult[5] = partialCounter;
        //Put counters for exact and partials as 4 and 5 of result array

        for(int m = 0; m < 4; m++) {
            testAnswer[m] = testAnswerOriginal[m];
        }
        //Set answer to original answer because some guess digits might be removed
        return testResult;
        //Return the testresult array
    }
}
