package com.guess;

import org.springframework.stereotype.Repository;
import java.sql.SQLException;
import java.util.Arrays;

@Repository
public class PlayView {
    public static void play() throws SQLException {
        DaoTest.loadTests();
        String daoTestReturn = DaoTest.allDaoTests();
        if (daoTestReturn.equals("false")) {
            System.exit(0);
        }
        //Load the Game Test Objects
        //Run all the tests on the objects
        //If returns false then exit the application

        while(true) {
            View.displayPrevious();
            View.gameChoice();
        }
        //Always display previous games and ask for game choice
    }

    public static void playNew() throws SQLException {
        GameDao newGame = new GameDao();
        Database db = new Database();
        db.create(newGame.id,newGame.answer);
        int gameRounds = newGame.round;
        //Create database object and invoke create to add it to mysql database
        //Create new game object for this game

        while (true) {
            if (gameRounds > 10) {
                System.out.println("Game Over.  All rounds finished.");
                break;
            }
            //If rounds are greater then 10 then end game and display game over message

            int[] userArray = Arrays.copyOf(View.gameInput(),4);
            int[] resultArray = Service.result(userArray, newGame);
            String resultLog = "";
            //Assign the results of gameinput to an int array
            //Assign the results of the guess for the game to int array
            //Resultlog will be result log

            for (int l = 0; l < userArray.length; l++) {
                resultLog += userArray[l];
                System.out.print(userArray[l]);
                if (l != (userArray.length - 1)) {
                    resultLog += ",";
                    System.out.print(",");
                }
            }
            //Print out each int of user guess
            //Add user's guess to resultlog
            resultLog += ":";
            System.out.println("");

            for (int b = 0; b < 4; b++) {
                if (resultArray[b] == 1) {
                    resultLog += "par";
                    System.out.print("par");
                } else if (resultArray[b] == 2) {
                    resultLog += "exa";
                    System.out.print("exa");
                } else if (resultArray[b] == 0) {
                    resultLog += "wro";
                    System.out.print("wro");
                }
                if (b != 3) {
                    resultLog += ",";
                    System.out.print(",");
                }
            }
            //Using result array depending on int then display if partial exact or wrong
            //Add exa,par,wro's to resultlog

            System.out.println("");
            System.out.println("e:" + resultArray[4] + ":p:" + resultArray[5]);
            System.out.println("Rounds Played: " + gameRounds);
            //Display rounds and total exacts/partials
            resultLog = " " + gameRounds  + ". " + resultLog + newGame.getLog();
            db.setLog(newGame.getId(),resultLog);
            newGame.setLog(resultLog);
            //Put most recent roundlog to front of all other rounds
            //Combine all logs into one variable
            //Set database to new log
            //Set log to new log

            if (resultArray[4] == 4) {
                System.out.println("You Won.");
                newGame.progress = 2;
                db.setProgress(newGame.id,2);
                break;
            }
            //If the amount of exacts is 4 then display win message
            //Set game to 2 for game is finished and won
            //Use database object to set progress to 2 in mysql entry

            gameRounds = Service.rounds(newGame);
            //Invoke rounds and set to gamerounds to add 1 round

            if (gameRounds > 10) {
                System.out.println("Game Over.  You Lose.");
                newGame.progress = 1;
                db.setProgress(newGame.id,1);
                break;
            }
            //If the amount of rounds is 11 which means 10 been played
            //Then display lost message
            //Set progress to 1
            //Set mysql progress entry for game to lost
            //End game
        }
    }

    public static void playOld(int gameindex) throws SQLException {
        //Same as playnew except to have a gameid input
        //Use gameid input to get the game from the ArrayList
        //Use getters to get the various info for the game

        Database db = new Database();
        int gameRounds = GameDao.Games.get(gameindex).getRound();
        while (true) {
            if (gameRounds > 10) {
                System.out.println("Game Over.  All rounds finished.");
                break;
            }
            int[] userArray = Arrays.copyOf(View.gameInput(), 4);
            int[] resultArray = Service.result(userArray, GameDao.Games.get(gameindex).getGame());
            String resultLog = "";

            for (int l = 0; l < userArray.length; l++) {
                resultLog += userArray[l];
                System.out.print(userArray[l]);
                if (l != (userArray.length - 1)) {
                    resultLog += ",";
                    System.out.print(",");
                }
            }
            System.out.println("");
            resultLog += ":";

            for (int b = 0; b < 4; b++) {
                if (resultArray[b] == 1) {
                    resultLog += "par";
                    System.out.print("par");
                } else if (resultArray[b] == 2) {
                    resultLog += "exa";
                    System.out.print("exa");
                } else if (resultArray[b] == 0) {
                    resultLog += "wro";
                    System.out.print("wro");
                }
                if (b != 3) {
                    resultLog += ",";
                    System.out.print(",");
                }
            }
            System.out.println("");
            System.out.println("e:" + resultArray[4] + ":p:" + resultArray[5]);
            System.out.println("Rounds Played: " + gameRounds);
            resultLog = " " + gameRounds + ". " + resultLog + GameDao.Games.get(gameindex).getLog() + " ";
            db.setLog(gameindex,resultLog);
            GameDao.Games.get(gameindex).setLog(resultLog);
            if (resultArray[4] == 4) {
                System.out.println("You Won.");
                GameDao.Games.get(gameindex).progress = 2;
                db.setProgress(GameDao.Games.get(gameindex).id,2);
                break;
            }
            gameRounds = Service.rounds(GameDao.Games.get(gameindex).getGame());
            if (gameRounds > 10) {
                System.out.println("Game Over.  You Lose.");
                GameDao.Games.get(gameindex).progress = 1;
                db.setProgress(GameDao.Games.get(gameindex).id,1);
                break;
            }
        }
    }
}
