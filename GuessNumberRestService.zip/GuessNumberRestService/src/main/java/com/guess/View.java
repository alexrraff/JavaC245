package com.guess;

import java.sql.SQLException;
import java.util.Scanner;

public class View {
    public static int[] gameInput() throws SQLException {
        Scanner inpObj = new Scanner(System.in);
        String gameInput = "";
        while (gameInput.length() < 4) {
            System.out.println("- Enter 4 digit guess:");
            System.out.println("- Enter Break to Stop Game:");
            gameInput = inpObj.nextLine();
            if (gameInput.equals("Break")) {
                PlayView.play();
            }
        }
        //While length of input is less than 4 then get new input
        //Get the input of user and if it is Break then invoke start of game

        char[] userArrayChar = gameInput.toCharArray();
        int[] userArray = new int[4];
        //Assign the input to a char array of length 4

        userArray[0] = Character.getNumericValue(userArrayChar[0]);
        userArray[1] = Character.getNumericValue(userArrayChar[1]);
        userArray[2] = Character.getNumericValue(userArrayChar[2]);
        userArray[3] = Character.getNumericValue(userArrayChar[3]);
        //Assign the numeric value of each char to be ints in integer array
        return userArray;
        //Return integer array
    }

    public static void displayPrevious() {
        System.out.println("|Previous Games: ");
        for (int i = 1; i < GameDao.Games.size(); i++) {
            System.out.print("|Game Number: " + i);
            switch (GameDao.Games.get(i).getProgress()) {
                case 0:
                    System.out.print(" |Progress: In Progress");
                    System.out.print(" |Round: " + GameDao.Games.get(i).getRound());
                    System.out.print(" |Log: " + GameDao.Games.get(i).getLog());
                    break;
                case 1:
                    System.out.print(" |Answer: " + GameDao.Games.get(i).getAnswer());
                    System.out.print(" |Progress: Lost");
                    break;
                case 2:
                    System.out.print(" |Answer: " + GameDao.Games.get(i).getAnswer());
                    System.out.print(" |Progress: Won");
                    break;
            }
            System.out.println("");
            //Display all previous games with the correct information to be displayed
        }
    }

    public static void gameChoice() throws SQLException {
        String userInput;
        Scanner inpObj = new Scanner(System.in);
        //Create scanner and input string

        System.out.println("- Enter New for New Game:");
        System.out.println("- Enter Number of Game for Old Game:");
        System.out.println("- Enter Quit to Quit:");
        userInput = inpObj.nextLine();
        //Get user input for choice

        if (userInput.equals("New")) {
            PlayView.playNew();
        } else if (userInput.equals("Quit")) {
            System.exit(0);
        }
        //If input is new then Invoke playnew for a new game
        //If input is quit then exit the game

        try {
            int gameNumber = Integer.parseInt(userInput);
            if (gameNumber < GameDao.Games.size() && gameNumber > 0) {
                PlayView.playOld(gameNumber);
            }
        } catch (Exception e) {
            PlayView.play();
        }
        //Try to parse the input into an integer to select a game
        //Invoke playold with gameid input
        //If parse fails then just invoke game from start again
    }
}
