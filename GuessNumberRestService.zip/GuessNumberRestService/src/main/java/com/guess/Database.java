package com.guess;

import java.sql.SQLException;
import com.mysql.cj.jdbc.MysqlDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import java.sql.*;
import java.util.List;
//Import necessary classes


public class Database {
    public String dbURL = "jdbc:mysql://localhost:3306/guessint";
    public String dbUser = "root";
    public String dbPassword = "alexalex";
    //Set public variables for the mysql connection

    public Database(){}

    @Autowired
    public int addRound(int gameid, int gameprogress) throws SQLException {
        String sql;
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        sql = "UPDATE games SET " + "round = ? "  + "WHERE id = ?;";
        return jdbcTemplate.update(sql,gameprogress,gameid);
        //Create database object and use it to create jdbctemplate
        //Use SQL to update the round to the input amount
    }

    public int setProgress(int gameid, int gameprogress) throws SQLException {
        String sql;
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        sql = "UPDATE games SET " + "progress = ? "  + "WHERE id = ?;";
        return jdbcTemplate.update(sql,gameprogress,gameid);
        //Use SQL to update progress to won or lost
    }

    public int setLog(int gameid, String logadd) throws SQLException {
        String sql;
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        sql = "UPDATE games SET " + "log = ? "  + "WHERE id = ?;";
        return jdbcTemplate.update(sql,logadd, gameid);
        //Use SQL to update log
    }

    public int create(int id, int answer) throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String newlog = "";
        String sql = "INSERT INTO games(id, answer, progress, round, log) VALUES(?,?,0,1,?);";

        return jdbcTemplate.update(sql, id,answer,newlog);
        //Use SQL to create new row in db with the proper information
    }

    public List<GameDao> loadGames() {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setURL(dbURL);
        dataSource.setUser(dbUser);
        dataSource.setPassword(dbPassword);
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String SQL = "select * from games";

        return jdbcTemplate.query(SQL, new GameMapper());
        //Use Row mapper to create a new Game object for each row
    }


    private static final class GameMapper implements RowMapper<GameDao> {

        public GameDao mapRow(ResultSet rs, int index) throws SQLException {
            GameDao td = new GameDao();
            td.setId(rs.getInt("id"));
            td.setAnswer(rs.getInt("answer"));
            td.setProgress(rs.getInt("progress"));
            td.setRound(rs.getInt("round"));
            td.setLog(rs.getString("log"));
            return td;
            //Create a new Game and use SQL to get the information for it
            //Use setters to assign info to object
        }
    }
}


