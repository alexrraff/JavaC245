package com.guess;

import java.util.ArrayList;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.lang.Math;

public class DaoTest {
    //Create DaoTest class for tests and objects

    int answer, id, round, progress;
    String log;
    public static ArrayList<DaoTest> DaoTests = new ArrayList<DaoTest>();
    //Array of Test objects
    public DaoTest() {
        int[] newAnswerArray = new int[4];
        for (int n = 0; n < 4; n++) {
            int randomInt = (int) ((Math.random() * 10));
            while (randomInt == newAnswerArray[0] | randomInt == newAnswerArray[1] | randomInt == newAnswerArray[2]) {
                randomInt = (int) ((Math.random() * 10));
            }
            newAnswerArray[n] = randomInt;
        }

        int answer = 0;
        int ff = 3;
        for (int f = 0; f < 4; f++) {
            answer += (newAnswerArray[f] * ((int)Math.pow(10,ff)));
            ff--;
        }

        this.id = DaoTests.size();
        this.answer = answer;
        this.progress = 0;
        this.round = 1;
        this.log = "";
        DaoTests.add(this);
    }
    //DaoTest class objects

    public DaoTest getDaoTest() {return this;}
    //Getter to return test object

    public static void loadTests() {
        DaoTest d0 = new DaoTest();
        DaoTest d1 = new DaoTest();
        d1.progress = 2;
        d1.round = 3;
        DaoTest d2 = new DaoTest();
        d2.progress = 1;
        d2.round = 11;
        DaoTest d3 = new DaoTest();
        d3.round = 11;
        d3.progress = 2;
        //Create DaoTest objects and set key attributes
        //For the Tests
    }

    public static boolean duplicateTest(DaoTest daotest) {
        int daoAnswer = daotest.answer;
        int[] daoAnswerArray = {(daoAnswer / 1000), (daoAnswer / 100) % 10, (daoAnswer / 10) % 10, (daoAnswer % 10)};
        for (int k = 4; k < 4; k++) {
            if (daoAnswerArray[0] == daoAnswerArray[1] || daoAnswerArray[0] == daoAnswerArray[2] || daoAnswerArray[0] == daoAnswerArray[3]) {
                if (daoAnswerArray[1] == daoAnswerArray[2] || daoAnswerArray[1] == daoAnswerArray[3]) {
                    if (daoAnswerArray[2] == daoAnswerArray[3]) {
                        return false;
                    }
                }
            }
        }
        return true;
        //Test that the answer generated contains no duplicates
    }

    public static boolean addroundTest(DaoTest daotest) {
        int daoTestRound = daotest.round;
        int daoTestRoundChange = 1 + daoTestRound;
        if (daoTestRoundChange - daoTestRound == 1) {
            return true;
        } else {
            return false;
        }
        //Test that rounds can be increased by one
    }

    public static boolean endroundTest(DaoTest daotest) {
        if (daotest.round > 10 && daotest.progress == 0) {
            return false;
        } else {
            return true;
        }
        //Test that if round is above 10 then the progress has been set to 1 or 2
        //1 or 2 is won or lost
    }

    public static String allDaoTests() {
        for(int j = 0; j < 4; j++) {
            if (duplicateTest(DaoTest.DaoTests.get(j).getDaoTest()) == false) {
                return "false";
            }
            if (addroundTest(DaoTest.DaoTests.get(j).getDaoTest()) == false) {
                return "false";
            }

            if (endroundTest(DaoTest.DaoTests.get(j).getDaoTest()) == false) {
                return "false";
            }
        }
        return "true";
        //Loop through all the DaoTest Objects
        //Run the three tests on each object
        //If a test returns false then the allDaoTests returns false
    }
}
