package com.guess;

public interface GameDaoInt {
    //Interface template for the Game class to implement
    public int getId();

    public int getAnswer();

    public int getProgress();

    public int getRound();
    public String getLog();

    public void setId(int id);

    public void setAnswer(int answer);

    public void setProgress(int progress);

    public void setRound(int round);
    public void setLog(String log);

    public GameDao getGame();

}
