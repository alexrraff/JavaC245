package com.guess;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.lang.Math;

@Repository
public class GameDao implements GameDaoInt {
    //Implement GameDao Interface
    int answer, id, round, progress;
    String log;

    public static ArrayList<GameDao> Games = new ArrayList<GameDao>();
    //Create ArrayList for all the games to be loaded into

    public GameDao() {
        int[] newAnswerArray = new int[4];
        for (int n = 0; n < 4; n++) {
            int randomInt = (int) ((Math.random() * 10));
            while (randomInt == newAnswerArray[0] | randomInt == newAnswerArray[1] | randomInt == newAnswerArray[2]) {
                randomInt = (int) ((Math.random() * 10));
            }
            newAnswerArray[n] = randomInt;
            //Loop 4 times to create a random number from 0 to 9
            //If any new number is already in one of the other positions
            //The while loop will run again to find a new number
        }
        int answer = 0;
        int ff = 3;
        for (int f = 0; f < 4; f++) {
            answer += (newAnswerArray[f] * ((int)Math.pow(10,ff)));
            ff--;
        }
        //Loop 4 times through array multiplying each number by the tens amount of its place
        //Start at 1000s then 100s then 10s then 1

        this.id = GameDao.Games.size();
        this.answer = answer;
        this.progress = 0;
        this.round = 1;
        this.log = "";
        Games.add(this);
        //Assign the proper info to the Game Object
        //The size includes 0 so it will be the next number up
        //Answer is the answer generated
        //Progress is 0 for in progress and round 1
        //Add it to the Arraylist
    }

    @Override
    public int getId() {return this.id;}
    @Override
    public int getAnswer() {return this.answer;}
    @Override
    public int getProgress() {return this.progress;}
    @Override
    public int getRound() {return this.round;}
    @Override
    public String getLog() {return this.log;}
    //All getters return as ints or log string
    @Override
    public void setId(int id) { this.id =  id;}
    @Override
    public void setAnswer(int answer) {this.answer = answer;}
    @Override
    public void setProgress(int progress) {this.progress = progress;}
    @Override
    public void setRound(int round) {this.round = round;}

    @Override
    public void setLog(String log) {this.log = log;}
    //All setters take an int input or log string
    @Override
    public GameDao getGame() {return this;}
    //Getter returns the game object itself
}
