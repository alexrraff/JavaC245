package com.guess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.sql.SQLException;
//Import the necessary classes

@SpringBootApplication
public class App {
    //Define as SpringBootApplication Main
    public static void main(String[] args) throws SQLException {
        SpringApplication.run(App.class, args);
        Service.loadGames();
        //Load all the Games from MySQL database into Game.Games ArrayList

        PlayView.play();
        //Run this class
        //Load the games by invoking loadGames method from Service
        //Invoke play game
    }
}