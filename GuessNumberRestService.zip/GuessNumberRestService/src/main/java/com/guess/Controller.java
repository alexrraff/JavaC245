package com.guess;

import org.springframework.web.bind.annotation.*;
import java.sql.SQLException;

@RestController
@RequestMapping("/guessint")
public class Controller {
    //Create Controller and set its url

    @PostMapping("/begin")
    public String[] GameCreate() throws SQLException {
        int gamesSize = GameDao.Games.size();
        GameDao newGame = new GameDao();
        String gameNumber = "gamenumber: " + gamesSize;
        String gameProgress = "Game in Progress";
        String gameRound = "Round: " + newGame.round;
        Database db = new Database();
        db.create(newGame.id,newGame.answer);

        String[] gameReturn = {gameNumber, gameProgress, gameRound};
        return gameReturn;
        //Set as post and create new game then return the information
        //Add game to MySQL DB
    }

    @PostMapping("/guess")
    public String guess(int gameid, int guess1, int guess2, int guess3, int guess4) throws SQLException {
        if (GameDao.Games.get(gameid).progress != 0) {
            return "";
        }
        int[] guessArray = {guess1, guess2, guess3, guess4};
        int[] resultArray = Service.result(guessArray, GameDao.Games.get(gameid).getGame());
        String stringReturn = "";
        String resultLog = String.valueOf(guess1) + String.valueOf(guess2) + String.valueOf(guess3) + String.valueOf(guess4) + ":";
        Service.rounds(GameDao.Games.get(gameid).getGame());
        for (int b = 0; b < 4; b++) {
            if (resultArray[b] == 1) {
                resultLog += "par";
                stringReturn = stringReturn + "par";
            } else if (resultArray[b] == 2) {
                resultLog += "exa";
                stringReturn = stringReturn + "exa";
            } else if (resultArray[b] == 0) {
                resultLog += "wro";
                stringReturn = stringReturn + "wro";
            }
            if (b != 3) {
                resultLog += ",";
                stringReturn = stringReturn + ",";
            }
        }
        Database db = new Database();
        if (GameDao.Games.get(gameid).getRound() > 10) {
            System.out.println("Game Over.  You Lose.");
            GameDao.Games.get(gameid).progress = 1;
            db.setProgress(gameid,1);
        }
        if (resultArray[4] == 4) {
            System.out.println("You Won.");
            GameDao.Games.get(gameid).progress = 2;
            db.setProgress(gameid,2);
        }
        stringReturn = stringReturn + " | e:" + resultArray[4] + ":p:" + resultArray[5];
        resultLog = " " + (GameDao.Games.get(gameid).getRound() - 1)  + ". " + resultLog + GameDao.Games.get(gameid).getLog();
        db.setLog(gameid,resultLog);
        GameDao.Games.get(gameid).setLog(resultLog);
        return stringReturn;
        //Create guess with post and gameid and 4 guess inputs
        //Invoke result and get it by assigning it to array
        //Loop through the results for the partial, exacts, wrongs
        //Display amount of partials and exacts
        //Get the round log and set to object and MySQL DB
        //If the progress is set to won or lost then return nothing and end guess
        //If 10th round is reached set to lost
        //If game is own the set to won
    }

    @GetMapping("/game/{gameId}")
    public String GameGet(@PathVariable int gameId) {
        String stringReturn;

            stringReturn = "|Game Number: " + gameId;
            switch (GameDao.Games.get(gameId).getProgress()) {
                case 0:
                    stringReturn = stringReturn + " |Progress: In Progress";
                    stringReturn = stringReturn + " |Round: " + GameDao.Games.get(gameId).getRound();
                    stringReturn = stringReturn + " |Log: " + GameDao.Games.get(gameId).log;
                    break;
                case 1:
                    stringReturn = stringReturn + " |Answer: " + GameDao.Games.get(gameId).getAnswer();
                    stringReturn = stringReturn + " |Progress: Lost";
                    break;
                case 2:
                    stringReturn = stringReturn + " |Answer: " + GameDao.Games.get(gameId).getAnswer();
                    stringReturn = stringReturn + " |Progress: Won";
                    break;
            }
            return stringReturn;
            //Get with gameid input then display gameinput with answer instead of rounds
            //if not won or lost
            //Return as String
    }

    @GetMapping("/get")
    public String[] GamesGet() {
        String stringReturn;
        String[] arrayReturn = new String[GameDao.Games.size()];

        for (int i = 1; i < GameDao.Games.size(); i++) {
            stringReturn = "|Game Number: " + i;
            switch (GameDao.Games.get(i).getProgress()) {
                case 0:
                    stringReturn = stringReturn + " |Progress: In Progress";
                    stringReturn = stringReturn + " |Round: " + GameDao.Games.get(i).getRound();
                    stringReturn = stringReturn + " |Log: " + GameDao.Games.get(i).log;
                    break;
                case 1:
                    stringReturn = stringReturn + " |Answer: " + GameDao.Games.get(i).getAnswer();
                    stringReturn = stringReturn + " |Progress: Lost";
                    break;
                case 2:
                    stringReturn = stringReturn + " |Answer: " + GameDao.Games.get(i).getAnswer();
                    stringReturn = stringReturn + " |Progress: Won";
                    break;
            }
            arrayReturn[i] = stringReturn;
        }
        return arrayReturn;
        //Display the right information for all games
        //Return as array
    }
}
